'use strict';
const crypto=require('crypto');
const E=require('./engine');
const now=()=>Date.now();
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const id=(n=9)=>crypto.randomBytes(n).toString('base64url').slice(0,n);
const clean=s=>String(s||'').replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/g,'').trim();

// one table. authoritative: holds the deck, deals, runs timers, never leaks hole cards.
class Room {
  constructor(cfg, send){
    this.id=cfg.id; this.send=send; // send(connId, msg)
    this.cfg=cfg; // {id,name,variant,label,omaha,n,seats,sb,bb,min,max,actTime,bank,ownerToken}
    this.seats=new Array(cfg.seats).fill(null); // {token,name,conn,stack,sittingOut,buyIn,cashOut,bank,...per-hand}
    this.conns=new Map(); // connId -> {token,name,seat,spectator}
    this.tokens=new Map(); // token -> {name,seat,bankMs,lastSeen}
    this.buttonSeat=-1; this.handNo=0; this.phase='idle'; this.board=[]; this.deck=[];
    this.pot=0; this.currentBet=0; this.minRaise=cfg.bb; this.street='';
    this.toAct=null; this.actEnd=0; this.actTotal=0; this.actPhase='act'; this.timer=null; this.loopLock=false;
    this.chat=[]; this.ledger=[]; this.rev=0; this.running=false; this.waiters=[];
    this.lastActivity=now();
  }
  // ---- helpers ----
  occupied(){ return this.seats.filter(Boolean); }
  inHand(){ return this.occupied().filter(p=>p.inHand); }
  live(){ return this.inHand().filter(p=>!p.folded); }
  seatOf(token){ return this.seats.findIndex(p=>p&&p.token===token); }
  isOwner(token){ return token&&token===this.cfg.ownerToken; }
  touch(){ this.lastActivity=now(); }
  bump(){ this.rev++; this.broadcast(); }
  wake(){ const w=this.waiters; this.waiters=[]; w.forEach(f=>f()); }
  sleep(){ return new Promise(res=>this.waiters.push(res)); }

  // ---- connection lifecycle ----
  join(connId, token, name){
    token=token&&/^[A-Za-z0-9_-]{6,40}$/.test(token)?token:id(16);
    name=clean(name).slice(0,14)||'Khách';
    let rec=this.tokens.get(token);
    if(!rec){ rec={name,seat:-1,bankMs:this.cfg.bank*1000}; this.tokens.set(token,rec); }
    rec.name=name; rec.lastSeen=now();
    this.conns.set(connId,{token,name,seat:rec.seat});
    // reclaim seat on reconnect
    const s=this.seatOf(token);
    if(s>=0){ this.seats[s].conn=connId; this.seats[s].disconnectedAt=0; this.seats[s].name=name; }
    this.touch();
    this.sendFull(connId);
    this.sysLedger(`${name} vào phòng`);
    this.bump();
    return token;
  }
  leave(connId){
    const c=this.conns.get(connId); if(!c) return;
    this.conns.delete(connId);
    const s=this.seatOf(c.token);
    if(s>=0){ const p=this.seats[s]; if(p.conn===connId){ p.conn=null; p.disconnectedAt=now(); } }
    this.touch(); this.bump();
  }
  empty(){ return this.conns.size===0; }

  // ---- seating ----
  sit(connId, seat, name, buyIn){
    const c=this.conns.get(connId); if(!c) return this.err(connId,'Phiên không hợp lệ.');
    seat=Number(seat); buyIn=Math.round(Number(buyIn));
    if(!Number.isInteger(seat)||seat<0||seat>=this.cfg.seats) return this.err(connId,'Ghế không hợp lệ.');
    if(this.seatOf(c.token)>=0) return this.err(connId,'Bạn đã ngồi ở bàn.');
    if(this.seats[seat]) return this.err(connId,'Ghế này đã có người.');
    if(this.cfg.doubleBoard!=='off'&&this.occupied().length>=E.maxSeats(this.cfg.n,true)) return this.err(connId,'Bàn đã đủ người cho double board.');
    if(!(buyIn>=this.cfg.min&&buyIn<=this.cfg.max)) return this.err(connId,`Buy-in phải từ ${this.cfg.min} đến ${this.cfg.max}.`);
    name=clean(name).slice(0,14)||c.name;
    const rec=this.tokens.get(c.token); rec.seat=seat; rec.name=name; c.name=name;
    const p={token:c.token,name,conn:connId,seat,stack:buyIn,buyIn,cashOut:0,hands:0,bank:rec.bankMs,
      sittingOut:false,wantLeave:false,straddle:false,inHand:false,hole:[],bet:0,total:0,folded:false,allIn:false,acted:false,disconnectedAt:0};
    this.seats[seat]=p; c.seat=seat;
    this.ledgerEntry(c.token,name,'buyin',buyIn);
    this.sysLedger(`${name} ngồi ghế ${seat+1}, buy-in ${buyIn}`);
    this.touch(); this.maybeStart(); this.bump();
  }
  addOn(connId, amt){
    const c=this.conns.get(connId); const s=this.seatOf(c&&c.token); if(s<0) return;
    const p=this.seats[s]; amt=Math.round(Number(amt));
    if(!(amt>0)) return this.err(connId,'Số chip không hợp lệ.');
    if(p.stack+amt>this.cfg.max) return this.err(connId,`Tổng chip trên bàn không vượt ${this.cfg.max}.`);
    if(p.inHand){ p.pendingAddOn=(p.pendingAddOn||0)+amt; this.err(connId,`Sẽ nạp ${amt} sau ván này.`); }
    else { p.stack+=amt; p.buyIn+=amt; this.ledgerEntry(p.token,p.name,'buyin',amt); this.sysLedger(`${p.name} nạp thêm ${amt}`); }
    this.touch(); this.bump();
  }
  stand(connId){
    const c=this.conns.get(connId); const s=this.seatOf(c&&c.token); if(s<0) return;
    const p=this.seats[s];
    if(p.inHand&&!p.folded){ p.wantLeave=true; this.sysLedger(`${p.name} sẽ rời sau ván`); }
    else this.removeSeat(s,'đứng dậy');
    this.touch(); this.bump();
  }
  sitOut(connId,out){
    const c=this.conns.get(connId); const s=this.seatOf(c&&c.token); if(s<0) return;
    this.seats[s].sittingOut=!!out; this.touch(); this.bump(); this.maybeStart();
  }
  removeSeat(s,why){
    const p=this.seats[s]; if(!p) return;
    if(p.stack>0||p.buyIn>0) this.ledgerEntry(p.token,p.name,'cashout',p.stack);
    p.cashOut+=p.stack;
    const rec=this.tokens.get(p.token); if(rec) rec.seat=-1;
    const c=[...this.conns.values()].find(x=>x.token===p.token); if(c) c.seat=-1;
    this.seats[s]=null; this.sysLedger(`${p.name} rời bàn với ${p.stack}`);
  }

  setStraddle(connId,on){
    const c=this.conns.get(connId); const s=this.seatOf(c&&c.token); if(s<0) return;
    if(!this.cfg.straddle) return this.err(connId,'Bàn này không bật straddle.');
    this.seats[s].straddle=!!on; this.touch(); this.bump();
  }
  discard(connId,card){
    const c=this.conns.get(connId); const s=this.seatOf(c&&c.token); if(s<0||this.phase!=='discard') return;
    const p=this.seats[s]; card=Number(card);
    if(!this.discarding||!this.discarding.has(s)||!p.hole.includes(card)) return;
    this.doDiscard(p,card);
  }
  doDiscard(p,card){
    p.hole=p.hole.filter(x=>x!==card); this.discarding.delete(p.seat); p.bub=null;
    if(!this.discarding.size&&this.discardDone) this.discardDone();
    this.bump();
  }
  bombNext(connId){
    const c=this.conns.get(connId); if(!this.isOwner(c&&c.token)) return this.err(connId,'Chỉ chủ bàn bật được.');
    this.nextBomb=!this.nextBomb; this.sysLedger(this.nextBomb?'Chủ bàn bật BOMB POT cho ván tới':'Chủ bàn hủy bomb pot ván tới');
    this.touch(); this.bump();
  }
  // ---- host controls ----
  kick(connId, seat){
    const c=this.conns.get(connId); if(!this.isOwner(c&&c.token)) return;
    const p=this.seats[seat]; if(!p) return;
    if(p.inHand&&!p.folded) p.wantLeave=true; else this.removeSeat(seat,'bị chủ bàn mời ra');
    this.bump();
  }
  updateCfg(connId, patch){
    const c=this.conns.get(connId); if(!this.isOwner(c&&c.token)) return this.err(connId,'Chỉ chủ bàn chỉnh được.');
    const d={sb:+patch.sb,bb:+patch.bb,actTime:+patch.actTime,bank:+patch.bank,min:+patch.min,max:+patch.max,bombAnte:+patch.bombAnte,bombEvery:Math.round(+patch.bombEvery)};
    for(const k in d) if(!Number.isFinite(d[k])) return this.err(connId,'Giá trị không hợp lệ.');
    if(d.sb<1||d.bb<1||d.sb>d.bb) return this.err(connId,'Blinds không hợp lệ.');
    if(d.min<d.bb||d.max<d.min) return this.err(connId,'Khoảng buy-in không hợp lệ.');
    if(d.actTime<3||d.actTime>600||d.bank<0||d.bank>3600) return this.err(connId,'Thời gian không hợp lệ.');
    if(d.bombAnte<1||d.bombAnte>100||d.bombEvery<0||d.bombEvery>100) return this.err(connId,'Thông số bomb pot không hợp lệ.');
    const dbl=['off','bomb','always'].includes(patch.doubleBoard)?patch.doubleBoard:this.cfg.doubleBoard;
    if(dbl!=='off'&&this.occupied().length>E.maxSeats(this.cfg.n,true)) return this.err(connId,`Double board chỉ đủ bài cho ${E.maxSeats(this.cfg.n,true)} người.`);
    d.doubleBoard=dbl; d.straddle=!!patch.straddle;
    if(!d.straddle) this.occupied().forEach(p=>p.straddle=false);
    Object.assign(this.cfg,d);
    if(patch.refill) this.tokens.forEach(r=>r.bankMs=d.bank*1000), this.occupied().forEach(p=>p.bank=d.bank*1000);
    this.sysLedger(`Chủ bàn đổi cài đặt: ${d.sb}/${d.bb}, ${d.actTime}s + ${d.bank}s, buy-in ${d.min}-${d.max}`);
    this.touch(); this.bump();
  }

  // ---- chat ----
  say(connId, text){
    const c=this.conns.get(connId); if(!c) return;
    text=clean(text).slice(0,200); if(!text) return;
    if(c._chatT&&now()-c._chatT<400) return; c._chatT=now();
    this.chat.push({name:c.name,text,t:now(),sys:false});
    if(this.chat.length>120) this.chat=this.chat.slice(-120);
    this.bump();
  }
  sysLedger(text){ this.chat.push({text,t:now(),sys:true}); if(this.chat.length>120) this.chat=this.chat.slice(-120); }
  ledgerEntry(token,name,type,amount){ this.ledger.push({token,name,type,amount,t:now()}); }

  // ---- action from a player ----
  action(connId, a){
    const c=this.conns.get(connId); if(!c) return;
    const pa=this.pending; if(!pa) return;
    const p=this.seats[pa.seat]; if(!p||p.token!==c.token) return;
    if(a.handNo!==this.handNo) return;
    const norm=this.normalize(p,a); if(!norm) return;
    pa.resolve(norm);
  }
  limits(p){
    const toCall=Math.max(0,this.currentBet-p.bet), allInTo=p.bet+p.stack, potNow=this.pot+this.sumBets();
    const potMax=this.currentBet+potNow+toCall;
    const max=this.cfg.omaha?Math.min(potMax,allInTo):allInTo, min=Math.min(this.currentBet+this.minRaise,max);
    const canRaise=p.stack>toCall&&this.live().some(q=>q!==p&&!q.allIn);
    return {toCall,min,max,canRaise,allInTo};
  }
  normalize(p,a){
    const L=this.limits(p);
    if(a.type==='fold') return {type:'fold'};
    if(a.type==='check') return L.toCall===0?{type:'check'}:null;
    if(a.type==='call') return L.toCall===0?{type:'check'}:{type:'call'};
    if(a.type==='raise'){ const to=Number(a.to); if(!Number.isFinite(to)) return null;
      if(!L.canRaise||L.max<=this.currentBet) return L.toCall===0?{type:'check'}:{type:'call'};
      return {type:'raise',to:clamp(Math.round(to),L.min,L.max)}; }
    return null;
  }
  sumBets(){ return this.inHand().reduce((s,p)=>s+p.bet,0); }

  // ---- game loop ----
  maybeStart(){ if(!this.running){ this.running=true; this.loop().catch(()=>{}).then(()=>{ this.running=false; }); } else this.wake(); }
  readyCount(){ return this.occupied().filter(p=>p.stack>0&&!p.sittingOut&&(p.conn||now()-p.disconnectedAt<30000)).length; }
  async waitForPlayers(){
    this.phase='waiting'; this.toAct=null; this.setTurn(null); this.bump();
    while(this.readyCount()<2){ await Promise.race([this.sleep(), new Promise(r=>setTimeout(r,2000))]); if(this.closed) throw 0; }
  }
  async loop(){
    while(!this.closed){
      // clean up disconnected/leaving between hands
      this.betweenHandsCleanup();
      if(this.readyCount()<2){ await this.waitForPlayers(); continue; }
      try{ await this.playHand(); }catch(e){ if(e!==0) { /*swallow*/ } }
      await new Promise(r=>setTimeout(r,1400));
    }
  }
  betweenHandsCleanup(){
    this.seats.forEach((p,i)=>{
      if(!p) return;
      if(p.wantLeave){ this.removeSeat(i,'rời bàn'); return; }
      if(!p.conn&&now()-p.disconnectedAt>60000){ this.removeSeat(i,'mất kết nối'); return; }
      if(p.pendingAddOn){ p.stack+=p.pendingAddOn; p.buyIn+=p.pendingAddOn; this.ledgerEntry(p.token,p.name,'buyin',p.pendingAddOn); this.sysLedger(`${p.name} nạp thêm ${p.pendingAddOn}`); p.pendingAddOn=0; }
    });
    this.bump();
  }
  setTurn(seat,phase,ms,total,human){
    this.toAct=seat==null?null:seat;
    this.actPhase=phase||'act'; this.actEnd=seat==null?0:now()+ms; this.actTotal=total||ms; this.actHuman=!!human;
  }
  async playHand(){
    const c=this.cfg;
    const players=this.occupied().filter(p=>p.stack>0&&!p.sittingOut&&(p.conn||now()-p.disconnectedAt<30000));
    if(players.length<2) return;
    this.handNo++; this.phase='hand'; this.board=[]; this.pot=0; this.street='preflop'; this.winInfo=null;
    const bomb=!!this.nextBomb||(c.bombEvery>0&&this.handNo%c.bombEvery===0); this.nextBomb=false;
    this.bomb=bomb; this.dbl=c.doubleBoard==='always'||(c.doubleBoard==='bomb'&&bomb);
    this.board2=this.dbl?[]:null; this.straddler=null;
    this.occupied().forEach(p=>{ p.inHand=players.includes(p); Object.assign(p,{hole:[],bet:0,total:0,folded:false,allIn:false,acted:false,shown:false,bub:null,win:false,best:null,best2:null}); });
    let bs=this.buttonSeat; do{ bs=(bs+1)%c.seats; }while(!players.some(p=>p.seat===bs));
    this.buttonSeat=bs;
    this.deck=E.shuffle(E.newDeck());
    const ord=players.slice().sort((a,b)=>((a.seat-bs+c.seats)%c.seats)-((b.seat-bs+c.seats)%c.seats));
    this.order=ord; const n=ord.length;
    this.sysLedger(`Ván #${this.handNo}${bomb?' (BOMB POT)':''}${this.dbl?' (2 board)':''}, nút cái: ${ord[0].name}`);
    this.currentBet=0; this.minRaise=c.bb;
    let preStart=0;
    if(bomb){
      const ante=c.bombAnte*c.bb;
      ord.forEach(p=>{ this.postBlind(p,ante); p.bub='Bomb'; });
      this.sysLedger(`Mỗi người góp ${ante} vào bomb pot`);
    } else {
      const sbP=n===2?ord[0]:ord[1], bbP=n===2?ord[1]:ord[2%n];
      this.postBlind(sbP,c.sb); sbP.bub='SB'; this.postBlind(bbP,c.bb); bbP.bub='BB';
      this.currentBet=Math.max(sbP.bet,bbP.bet,c.bb); this.minRaise=c.bb;
      preStart=(ord.indexOf(bbP)+1)%n;
      if(c.straddle&&n>=3){
        const utg=ord[preStart];
        if(utg!==sbP&&utg!==bbP&&utg.straddle&&utg.stack>0){
          this.postBlind(utg,2*c.bb); utg.bub=`Straddle ${utg.bet}`; this.straddler=utg;
          this.currentBet=Math.max(this.currentBet,utg.bet); this.minRaise=2*c.bb;
          this.sysLedger(`${utg.name} straddle ${utg.bet}`);
          preStart=(preStart+1)%n;
        }
      }
    }
    for(let r=0;r<c.n;r++) for(const p of ord) p.hole.push(this.deck.pop());
    ord.forEach(p=>{ p.hands++; });
    this.phase='deal'; this.bump(); await this.pause(650);
    if(!bomb) await this.bettingRound(preStart);
    else this.collectBets();
    const variant=E.VARIANTS.find(v=>v.id===c.variant)||{};
    if(variant.discard==='pre'&&this.live().length>1) await this.discardPhase();
    for(const [nm,k] of [['flop',3],['turn',1],['river',1]]){
      if(this.live().length<=1) break;
      this.collectBets();
      this.street=nm; this.dealBoard(k);
      this.phase='board:'+nm; this.bump();
      const runout=this.live().length>1&&this.inHand().filter(p=>!p.folded&&!p.allIn).length<=1;
      await this.pause(nm==='river'||runout?1200:850);
      if(!runout){ const bstart=(this.order.findIndex(p=>p.seat===bs)+1)%n; await this.bettingRound(bstart); }
      if(nm==='flop'&&variant.discard==='flop'&&this.live().length>1){ this.collectBets(); await this.discardPhase(); }
    }
    this.collectBets();
    await this.showdown();
    this.phase='result'; this.bump();
    await this.pause(this.dbl?3600:2600);
  }
  // Pineapple: every live player with 3 cards discards one, all at the same time, under one shared timer.
  async discardPhase(){
    const ps=this.live().filter(p=>p.hole.length===3); if(!ps.length) return;
    const prevPhase=this.phase;
    this.phase='discard'; this.discarding=new Set(ps.map(p=>p.seat));
    ps.forEach(p=>p.bub='Đang bỏ bài');
    const ms=this.cfg.actTime*1000; this.discardEnd=now()+ms; this.setTurn(null); this.bump();
    await new Promise(res=>{ this.discardDone=res; clearTimeout(this.timer); this.timer=setTimeout(()=>{ ps.forEach(p=>{ if(this.discarding.has(p.seat)) this.doDiscard(p,this.autoDiscard(p)); }); res(); },ms); });
    clearTimeout(this.timer); this.discardDone=null; this.discarding=null; this.discardEnd=0;
    this.sysLedger('Mọi người đã bỏ 1 lá');
    this.phase=prevPhase==='discard'?'hand':prevPhase; this.bump(); await this.pause(500);
  }
  autoDiscard(p){
    const h=p.hole; let best=null, keepScore=-1;
    for(let i=0;i<3;i++){
      const keep=h.filter((_,j)=>j!==i);
      let sc;
      if(this.board.length>=3) sc=E.bestHand(keep,this.board,false).score;
      else { const r=keep.map(x=>x>>2).sort((a,b)=>b-a); sc=(r[0]===r[1]?1000:0)+r[0]*15+r[1]+(((keep[0]&3)===(keep[1]&3))?8:0); }
      if(sc>keepScore){ keepScore=sc; best=h[i]; }
    }
    return best;
  }
  postBlind(p,amt){ amt=Math.min(amt,p.stack); p.stack-=amt; p.bet+=amt; p.total+=amt; if(p.stack===0) p.allIn=true; }
  dealBoard(k){
    const name=this.street[0].toUpperCase()+this.street.slice(1);
    this.deck.pop(); for(let i=0;i<k;i++) this.board.push(this.deck.pop());
    if(this.dbl){ this.deck.pop(); for(let i=0;i<k;i++) this.board2.push(this.deck.pop());
      this.sysLedger(`${name}: board 1 ${this.board.map(E.cStr).join(' ')}, board 2 ${this.board2.map(E.cStr).join(' ')}`); }
    else this.sysLedger(`${name}: ${this.board.map(E.cStr).join(' ')}`);
  }
  collectBets(){ this.inHand().forEach(p=>{ this.pot+=p.bet; p.bet=0; p.acted=false; if(!p.folded) p.bub=null; }); this.currentBet=0; this.minRaise=this.cfg.bb; this.bump(); }
  roundDone(){ const act=this.inHand().filter(p=>!p.folded&&!p.allIn); if(!act.length) return true; if(act.length===1&&this.live().length>1&&act[0].bet>=this.currentBet) return true; return act.every(p=>p.acted&&p.bet===this.currentBet); }
  async bettingRound(start){
    const ord=this.order, n=ord.length; let i=start%n, guard=0;
    while(guard++<2000){
      if(this.live().length<=1||this.roundDone()) break;
      const p=ord[i];
      if(p.inHand&&!p.folded&&!p.allIn&&(!p.acted||p.bet<this.currentBet)){
        const a=await this.awaitAction(p);
        this.applyAction(p,a);
        this.bump();
      }
      i=(i+1)%n;
    }
    this.setTurn(null); this.bump();
  }
  awaitAction(p){
    return new Promise(resolve=>{
      const c=this.cfg; let settled=false;
      const done=a=>{ if(settled) return; settled=true; clearTimeout(this.timer); this.pending=null; this.setTurn(null); resolve(a); };
      if(!p.conn&&now()-p.disconnectedAt>15000){ const L=this.limits(p); return done({type:L.toCall?'fold':'check'}); }
      this.pending={seat:p.seat,handNo:this.handNo,resolve:a=>{ p.missed=0; done(a); }};
      const actMs=c.actTime*1000;
      this.setTurn(p.seat,'act',actMs,actMs,true); this.bump();
      const auto=()=>{ p.bank=0; const L=this.limits(p); p.missed=(p.missed||0)+1; if(p.missed>=2) p.sittingOut=true; this.sysLedger(`${p.name} hết giờ`); done({type:L.toCall===0?'check':'fold'}); };
      this.timer=setTimeout(()=>{
        if(p.bank>500){ this.setTurn(p.seat,'bank',p.bank,c.bank*1000||p.bank,true); this.bump(); this.timer=setTimeout(auto,p.bank); const st=now(); this._bankStart=st; this._bankP=p; }
        else auto();
      },actMs);
      this._actP=p;
    });
  }
  applyAction(p,a){
    const toCall=Math.max(0,this.currentBet-p.bet);
    if(this.actPhase==='bank'&&this._bankP===p) p.bank=Math.max(0,this.actEnd-now());
    if(a.type==='fold'){ p.folded=true; p.bub='Fold'; this.sysLedger(`${p.name} bỏ bài`); }
    else if(a.type==='check'){ p.bub='Check'; }
    else if(a.type==='call'){ this.putIn(p,toCall); p.bub=p.allIn?`All-in ${p.bet}`:`Call ${p.bet}`; this.sysLedger(`${p.name} theo ${p.bet}${p.allIn?' (all-in)':''}`); }
    else if(a.type==='raise'){ const wasBet=this.currentBet===0, to=Math.min(a.to,p.bet+p.stack), rs=to-this.currentBet; this.putIn(p,to-p.bet); if(rs>=this.minRaise){ this.minRaise=rs; this.inHand().forEach(q=>{ if(q!==p) q.acted=false; }); } this.currentBet=Math.max(this.currentBet,to); p.bub=`${p.allIn?'All-in':(wasBet?'Bet':'Raise')} ${to}`; this.sysLedger(`${p.name} ${wasBet?'cược':'tố lên'} ${to}${p.allIn?' (all-in)':''}`); }
    p.acted=true;
  }
  putIn(p,amt){ amt=Math.min(amt,p.stack); if(amt<=0) return; p.stack-=amt; p.bet+=amt; p.total+=amt; if(p.stack===0) p.allIn=true; }
  revealHands(){ if(this.revealed) return; this.revealed=true; }
  buildPots(){
    const lv=[...new Set(this.live().map(p=>p.total))].sort((a,b)=>a-b), pots=[]; let prev=0;
    for(const L of lv){ let amt=0; this.inHand().forEach(p=>amt+=Math.max(0,Math.min(p.total,L)-prev)); if(amt>0) pots.push({amount:amt,elig:this.live().filter(p=>p.total>=L)}); prev=L; }
    const tot=this.inHand().reduce((s,p)=>s+p.total,0), got=pots.reduce((s,x)=>s+x.amount,0);
    if(pots.length&&tot>got) pots[pots.length-1].amount+=tot-got;
    return pots;
  }
  async showdown(){
    const nf=this.live(), omaha=this.cfg.omaha;
    if(nf.length===1){ const w=nf[0], amt=this.pot; w.stack+=amt; this.pot=0; w.win=true; this.winInfo={seats:[w.seat],name:w.name,text:`ăn ${amt}`,cards:null}; this.sysLedger(`${w.name} ăn ${amt} (không lật bài)`); return; }
    nf.forEach(p=>{
      p.shown=true; p.best=E.bestHand(p.hole,this.board,omaha);
      if(this.dbl){ p.best2=E.bestHand(p.hole,this.board2,omaha); p.bub=`${E.handName(p.best.score)} / ${E.handName(p.best2.score)}`; }
      else p.bub=E.handName(p.best.score);
      this.sysLedger(`${p.name} lật ${E.sortHand(p.hole,omaha).map(E.cStr).join(' ')}: ${p.bub}`);
    });
    const pots=this.buildPots();
    for(let i=pots.length-1;i>=0;i--){ if(pots[i].elig.length===1){ const w=pots[i].elig[0]; w.stack+=pots[i].amount; this.pot-=pots[i].amount; this.sysLedger(`Trả lại ${pots[i].amount} cho ${w.name}`); pots.splice(i,1); } }
    const boards=this.dbl?[['best',1],['best2',2]]:[['best',0]];
    const mains={};
    for(let i=pots.length-1;i>=0;i--){
      const pot=pots[i];
      const parts=this.dbl?[Math.ceil(pot.amount/2),Math.floor(pot.amount/2)]:[pot.amount];
      boards.forEach(([key,bn],bi)=>{
        const amt=parts[bi]; const top=Math.max(...pot.elig.map(p=>p[key].score)), ws=pot.elig.filter(p=>p[key].score===top);
        if(i===0) mains[bn]={ws,top,cards:ws[0][key].cards};
        const share=Math.floor(amt/ws.length); let rem=amt-share*ws.length;
        ws.forEach(w=>{ const a=share+(rem>0?1:0); if(rem>0) rem--; w.stack+=a; this.pot-=a; w.win=true; });
        this.sysLedger(`${i===0?(pots.length>1?'Main pot':'Pot'):'Side pot '+i}${bn?' board '+bn:''}: ${ws.map(w=>w.name).join(', ')} ${ws.length>1?'chia':'ăn'} ${amt}, ${E.handName(top)}`);
      });
    }
    this.pot=0;
    if(this.dbl&&mains[1]&&mains[2]){
      const n1=mains[1].ws.map(w=>w.name).join(' & '), n2=mains[2].ws.map(w=>w.name).join(' & ');
      this.winInfo={seats:[...new Set([...mains[1].ws,...mains[2].ws].map(w=>w.seat))],name:n1===n2?n1:`${n1} | ${n2}`,
        text:n1===n2?`ăn cả 2 board (${E.handName(mains[1].top)} / ${E.handName(mains[2].top)})`:`thắng board 1 (${E.handName(mains[1].top)}) | board 2 (${E.handName(mains[2].top)})`,
        cards:mains[1].cards,cards2:mains[2].cards,seat1:mains[1].ws[0].seat,seat2:mains[2].ws[0].seat};
    } else if(mains[0]) this.winInfo={seats:mains[0].ws.map(w=>w.seat),name:mains[0].ws.map(w=>w.name).join(' & '),text:`thắng với ${E.handName(mains[0].top)}`,cards:mains[0].cards,seat1:mains[0].ws[0].seat};
  }
  pause(ms){ this.bump(); return new Promise(r=>setTimeout(r,ms)); }

  // ---- serialization ----
  err(connId,msg){ this.send(connId,{t:'err',msg}); }
  publicSeat(p,viewerToken){
    if(!p) return null;
    const active=p.inHand&&this.phase!=='idle'&&this.phase!=='waiting';
    const mine=p.token===viewerToken;
    const showCards=p.shown||(mine&&p.inHand);
    return {seat:p.seat,name:p.name,stack:p.stack,bet:active?p.bet:0,folded:p.folded?1:0,allIn:p.allIn?1:0,
      sittingOut:p.sittingOut?1:0,disc:p.conn?0:1,you:mine?1:0,owner:this.isOwner(p.token)?1:0,wait:(!p.inHand&&this.phase!=='idle'&&this.phase!=='waiting')?1:0,
      cards:active&&showCards?E.sortHand(p.hole,this.cfg.omaha):(active&&p.inHand?p.hole.length:0),
      win:p.win?1:0,bub:active||this.phase==='result'?p.bub||null:null,bank:Math.round(p.bank/1000)};
  }
  stateFor(token){
    const c=this.cfg, viewer=this.conns.size?token:token;
    const t=this.toAct==null?null:{seat:this.toAct,ph:this.actPhase,r:Math.max(0,this.actEnd-now()),tot:this.actTotal,hu:this.actHuman?1:0};
    const mySeat=this.seatOf(token);
    return {t:'state',rev:this.rev,
      cfg:{id:c.id,name:c.name,variant:c.variant,label:c.label,omaha:c.omaha,n:c.n,seats:c.seats,sb:c.sb,bb:c.bb,min:c.min,max:c.max,actTime:c.actTime,bank:c.bank,straddle:!!c.straddle,doubleBoard:c.doubleBoard,bombAnte:c.bombAnte,bombEvery:c.bombEvery},
      phase:this.phase,handNo:this.handNo,btn:this.buttonSeat,board:this.board.slice(),board2:this.board2?this.board2.slice():null,pot:this.pot,cb:this.currentBet,mr:this.minRaise,
      bomb:this.bomb&&this.phase!=='waiting'?1:0,nextBomb:this.nextBomb?1:0,dbl:this.dbl&&this.phase!=='waiting'?1:0,
      discard:this.phase==='discard'?{r:Math.max(0,this.discardEnd-now()),tot:this.cfg.actTime*1000,me:mySeat>=0&&this.discarding&&this.discarding.has(mySeat)?1:0}:null,
      seats:this.seats.map(p=>this.publicSeat(p,token)),turn:t,win:this.winInfo||null,
      you:{token,seat:mySeat,owner:this.isOwner(token),straddle:mySeat>=0?!!this.seats[mySeat].straddle:false},
      chat:this.chat.slice(-60),count:this.occupied().length};
  }
  ledgerFor(token){
    const by={};
    this.ledger.forEach(e=>{ const k=e.token; (by[k]=by[k]||{name:e.name,buyin:0,cashout:0}); if(e.type==='buyin') by[k].buyin+=e.amount; else by[k].cashout+=e.amount; });
    this.occupied().forEach(p=>{ if(by[p.token]) by[p.token].onTable=p.stack; });
    return Object.entries(by).map(([k,v])=>({name:v.name,buyin:v.buyin,cashout:v.cashout,onTable:v.onTable||0,net:(v.cashout+(v.onTable||0))-v.buyin}));
  }
  sendFull(connId){ const c=this.conns.get(connId); this.send(connId,this.stateFor(c.token)); }
  broadcast(){ for(const [cid,c] of this.conns) this.send(cid,this.stateFor(c.token)); }
  close(){ this.closed=true; clearTimeout(this.timer); this.wake(); }
}
module.exports={Room,clean,id};
