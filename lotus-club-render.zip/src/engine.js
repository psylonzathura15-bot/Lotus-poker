'use strict';
const crypto=require('crypto');
const RANKS='23456789TJQKA', SUIT_CH=['♠','♥','♦','♣'];
const cRank=c=>c>>2, cSuit=c=>c&3;
const rankLabel=r=>r===10?'10':RANKS[r-2];
const cStr=c=>rankLabel(cRank(c))+SUIT_CH[cSuit(c)];
function newDeck(){ const d=[]; for(let r=2;r<=14;r++) for(let s=0;s<4;s++) d.push(r*4+s); return d; }
function shuffle(d){ for(let i=d.length-1;i>0;i--){ const j=crypto.randomInt(i+1); const t=d[i]; d[i]=d[j]; d[j]=t; } return d; }
const CNT=new Int8Array(15);
const B5=1048576;
function eval5(a,b,c,d,e){
  const s=a&3, flush=((b&3)===s)&&((c&3)===s)&&((d&3)===s)&&((e&3)===s);
  CNT.fill(0); CNT[a>>2]++; CNT[b>>2]++; CNT[c>>2]++; CNT[d>>2]++; CNT[e>>2]++;
  const g=[];
  for(let r=14;r>=2;r--) if(CNT[r]) g.push(CNT[r]*16+r);
  g.sort((x,y)=>y-x);
  let straight=0;
  if(g.length===5){
    const hi=g[0]&15, lo=g[4]&15;
    if(hi-lo===4) straight=hi; else if(hi===14 && (g[1]&15)===5) straight=5;
  }
  let cat;
  if(straight&&flush) cat=8;
  else if((g[0]>>4)===4) cat=7;
  else if((g[0]>>4)===3 && (g[1]>>4)===2) cat=6;
  else if(flush) cat=5;
  else if(straight) cat=4;
  else if((g[0]>>4)===3) cat=3;
  else if((g[0]>>4)===2 && (g[1]>>4)===2) cat=2;
  else if((g[0]>>4)===2) cat=1;
  else cat=0;
  let v=0, k=0;
  if(cat===8||cat===4){ v=straight; k=1; }
  else for(const x of g){ v=v*16+(x&15); k++; }
  for(;k<5;k++) v*=16;
  return cat*B5+v;
}
const COMB={};
function comb(n,k){
  const key=n+','+k; if(COMB[key]) return COMB[key];
  const res=[], cur=[];
  (function go(s){ if(cur.length===k){ res.push(cur.slice()); return; } for(let i=s;i<n;i++){ cur.push(i); go(i+1); cur.pop(); } })(0);
  return COMB[key]=res;
}
function bestHand(hole,board,omaha){
  let bs=-1, bc=null;
  if(omaha){
    if(board.length<3) return null;
    for(const p of comb(hole.length,2)){ const h0=hole[p[0]], h1=hole[p[1]];
      for(const t of comb(board.length,3)){ const x=board[t[0]], y=board[t[1]], z=board[t[2]]; const sc=eval5(h0,h1,x,y,z); if(sc>bs){ bs=sc; bc=[h0,h1,x,y,z]; } } }
  } else {
    const all=hole.concat(board); if(all.length<5) return null;
    for(const q of comb(all.length,5)){ const sc=eval5(all[q[0]],all[q[1]],all[q[2]],all[q[3]],all[q[4]]); if(sc>bs){ bs=sc; bc=q.map(i=>all[i]); } }
  }
  return {score:bs, cards:bc};
}
function bestScore(hole,board,omaha){
  let bs=-1;
  if(omaha){
    const P=comb(hole.length,2), T=comb(board.length,3);
    for(const p of P){ const h0=hole[p[0]], h1=hole[p[1]]; for(const t of T){ const sc=eval5(h0,h1,board[t[0]],board[t[1]],board[t[2]]); if(sc>bs) bs=sc; } }
  } else {
    const all=hole.concat(board);
    for(const q of comb(all.length,5)){ const sc=eval5(all[q[0]],all[q[1]],all[q[2]],all[q[3]],all[q[4]]); if(sc>bs) bs=sc; }
  }
  return bs;
}
function handName(score){
  const cat=Math.floor(score/B5), g0=Math.floor(score/65536)%16, g1=Math.floor(score/4096)%16;
  const R=rankLabel;
  switch(cat){
    case 8: return g0===14?'Thùng phá sảnh hoàng gia':`Thùng phá sảnh đến ${R(g0)}`;
    case 7: return `Tứ quý ${R(g0)}`;
    case 6: return `Cù lũ ${R(g0)}-${R(g1)}`;
    case 5: return `Thùng, cao ${R(g0)}`;
    case 4: return `Sảnh đến ${R(g0)}`;
    case 3: return `Bộ ba ${R(g0)}`;
    case 2: return `Hai đôi ${R(g0)} và ${R(g1)}`;
    case 1: return `Đôi ${R(g0)}`;
    default: return `Mậu thầu ${R(g0)}`;
  }
}

function sortHand(h,omaha){ return h.slice().sort((x,y)=> omaha ? (cSuit(x)-cSuit(y)) || (cRank(y)-cRank(x)) : (cRank(y)-cRank(x)) || (cSuit(x)-cSuit(y))); }
const VARIANTS=[{id:'NLHE',label:"Hold'em",n:2,omaha:false},
  {id:'PINE',label:'Pineapple',n:3,omaha:false,discard:'pre'},
  {id:'CPINE',label:'Crazy Pine',n:3,omaha:false,discard:'flop'}]
  .concat([4,5,6,7,8,9,10].map(n=>({id:'PLO'+n,label:'PLO'+n,n,omaha:true})));
// cards needed: hole*players + board(5 per board) + burns(3 per board) <= 52
const maxSeats=(n,dbl)=>Math.min(10,Math.floor((52-(dbl?16:8))/n));
module.exports={cStr,newDeck,shuffle,bestHand,handName,sortHand,VARIANTS,maxSeats,eval5};
