'use strict';
const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {WebSocketServer}=require('ws');
const E=require('./engine');
const {Room,clean,id}=require('./room');

const PORT=process.env.PORT||8080;
const PUBLIC=path.join(__dirname,'..','public');
const rooms=new Map(); // code -> Room

const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.ico':'image/x-icon'};
function serveFile(res,file){
  fs.readFile(file,(e,buf)=>{ if(e){ res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream'}); res.end(buf); });
}
function json(res,code,obj){ res.writeHead(code,{'Content-Type':'application/json'}); res.end(JSON.stringify(obj)); }
function body(req){ return new Promise(res=>{ let d=''; req.on('data',c=>{ d+=c; if(d.length>4096) req.destroy(); }); req.on('end',()=>{ try{ res(JSON.parse(d||'{}')); }catch(e){ res({}); } }); }); }

function makeRoom(cfg){
  const code=cfg.id;
  const r=new Room(cfg,(connId,msg)=>{ const ws=sockets.get(connId); if(ws&&ws.readyState===1) ws.send(JSON.stringify(msg)); });
  rooms.set(code,r); return r;
}
function validateCfg(d){
  const v=E.VARIANTS.find(x=>x.id===d.variant); if(!v) return 'Thể thức không hợp lệ.';
  const doubleBoard=['off','bomb','always'].includes(d.doubleBoard)?d.doubleBoard:'off';
  const seats=clamp(Math.round(+d.seats),2,E.maxSeats(v.n,doubleBoard!=='off'));
  const o={sb:+d.sb,bb:+d.bb,min:+d.min,max:+d.max,actTime:+d.actTime,bank:+d.bank,buyin:+d.buyin,bombAnte:+(d.bombAnte??2),bombEvery:Math.round(+(d.bombEvery??0))};
  for(const k in o) if(!Number.isFinite(o[k])) return 'Thiếu thông số.';
  if(o.sb<1||o.bb<1||o.sb>o.bb) return 'Blinds không hợp lệ.';
  if(o.min<o.bb||o.max<o.min) return 'Khoảng buy-in không hợp lệ.';
  if(o.actTime<3||o.actTime>600) return 'Thời gian lượt từ 3 đến 600 giây.';
  if(o.bank<0||o.bank>3600) return 'Timebank từ 0 đến 3600 giây.';
  if(o.bombAnte<1||o.bombAnte>100) return 'Ante bomb pot từ 1 đến 100 BB.';
  if(o.bombEvery<0||o.bombEvery>100) return 'Chu kỳ bomb pot từ 0 đến 100 ván.';
  return {variant:v.id,label:v.label,omaha:v.omaha,n:v.n,seats,straddle:!!d.straddle,doubleBoard,...o};
}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

const server=http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x');
  if(req.method==='POST'&&u.pathname==='/api/create'){
    const d=await body(req); const cfg=validateCfg(d);
    if(typeof cfg==='string') return json(res,400,{error:cfg});
    const name=clean(d.name).slice(0,28)||'Bàn poker';
    const owner=/^[A-Za-z0-9_-]{6,40}$/.test(d.ownerToken||'')?d.ownerToken:id(16);
    const code=id(6);
    makeRoom({id:code,name,ownerToken:owner,...cfg});
    return json(res,200,{code,ownerToken:owner});
  }
  if(u.pathname==='/health'||u.pathname==='/healthz'){ res.writeHead(200,{'Content-Type':'text/plain'}); return res.end('ok'); }
  if(u.pathname==='/api/rooms'){ // public lobby
    const list=[...rooms.values()].filter(r=>!r.closed).map(r=>({code:r.id,name:r.cfg.name,label:r.cfg.label,sb:r.cfg.sb,bb:r.cfg.bb,seats:r.cfg.seats,taken:r.occupied().length,min:r.cfg.min,max:r.cfg.max,players:r.conns.size}));
    return json(res,200,{rooms:list});
  }
  if(u.pathname==='/api/room'){ const r=rooms.get(u.searchParams.get('code')); if(!r||r.closed) return json(res,404,{error:'Không tìm thấy bàn.'}); return json(res,200,{code:r.id,name:r.cfg.name,label:r.cfg.label,sb:r.cfg.sb,bb:r.cfg.bb,min:r.cfg.min,max:r.cfg.max,seats:r.cfg.seats,taken:r.occupied().length}); }
  if(u.pathname==='/api/ledger'){ const r=rooms.get(u.searchParams.get('code')); if(!r) return json(res,404,{error:'x'}); return json(res,200,{ledger:r.ledgerFor()}); }
  // static
  let p=u.pathname==='/'?'/index.html':u.pathname;
  if(p.includes('..')) { res.writeHead(400); return res.end('bad'); }
  const file=path.join(PUBLIC,p);
  if(fs.existsSync(file)&&fs.statSync(file).isFile()) return serveFile(res,file);
  return serveFile(res,path.join(PUBLIC,'index.html')); // SPA fallback
});

const wss=new WebSocketServer({server,path:'/ws',maxPayload:8192});
const sockets=new Map(); // connId -> ws
wss.on('connection',ws=>{
  const connId=id(12); sockets.set(connId,ws); ws._alive=true; ws.on('pong',()=>{ ws._alive=true; }); ws._room=null; let msgs=0, winStart=Date.now();
  ws.on('message',raw=>{
    if(++msgs>40&&Date.now()-winStart<1000){ return; } if(Date.now()-winStart>=1000){ msgs=0; winStart=Date.now(); }
    let m; try{ m=JSON.parse(raw); }catch(e){ return; }
    if(m.t==='join'){
      const r=rooms.get(String(m.code||'')); if(!r||r.closed){ ws.send(JSON.stringify({t:'nojoin',msg:'Bàn không tồn tại.'})); return; }
      ws._room=r; ws._conn=connId;
      const token=r.join(connId,m.token,m.name);
      ws.send(JSON.stringify({t:'joined',token,code:r.id,owner:r.isOwner(token)}));
      return;
    }
    const r=ws._room; if(!r) return;
    switch(m.t){
      case 'sit': r.sit(connId,m.seat,m.name,m.buyin); break;
      case 'stand': r.stand(connId); break;
      case 'addon': r.addOn(connId,m.amt); break;
      case 'sitout': r.sitOut(connId,m.out); break;
      case 'act': r.action(connId,{type:String(m.type),to:m.to,handNo:m.handNo}); break;
      case 'say': r.say(connId,m.text); break;
      case 'kick': r.kick(connId,m.seat); break;
      case 'cfg': r.updateCfg(connId,m); break;
      case 'straddle': r.setStraddle(connId,m.on); break;
      case 'discard': r.discard(connId,m.card); break;
      case 'bomb': r.bombNext(connId); break;
      case 'ledger': ws.send(JSON.stringify({t:'ledger',ledger:r.ledgerFor()})); break;
    }
  });
  ws.on('close',()=>{ sockets.delete(connId); if(ws._room) ws._room.leave(connId); });
  ws.on('error',()=>{});
});

// reap empty rooms
setInterval(()=>{ for(const [code,r] of rooms){ if(r.conns.size===0&&Date.now()-r.lastActivity>1000*60*30){ r.close(); rooms.delete(code); } } },60000);

server.listen(PORT,'0.0.0.0',()=>console.log('Lotus Club server listening on port '+PORT));
// Ping every 25s: keeps proxies from cutting idle sockets and drops dead clients (recommended by Render/Fly).
setInterval(()=>{ wss.clients.forEach(ws=>{ if(ws._alive===false){ try{ ws.terminate(); }catch(e){} return; } ws._alive=false; try{ ws.ping(); }catch(e){} }); },25000);
process.on('SIGTERM',()=>{ server.close(()=>process.exit(0)); setTimeout(()=>process.exit(0),3000); });
module.exports={server,rooms};
