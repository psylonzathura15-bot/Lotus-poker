'use strict';
const $=(s,r=document)=>r.querySelector(s);
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
const store={ get(k,d){ try{ const v=localStorage.getItem(k); return v==null?d:JSON.parse(v); }catch(e){ return d; } }, set(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} } };
const RANKS='23456789TJQKA', SUITS='shdc', SUIT_CH=['♠','♥','♦','♣'], SUIT_NAME=['spade','heart','diamond','club'];
const cRank=c=>c>>2, cSuit=c=>c&3;
const rankLabel=r=>r===10?'10':RANKS[r-2];
const cStr=c=>rankLabel(cRank(c))+SUIT_CH[cSuit(c)];
function parseCard(s){
  s=s.trim(); if(!s) return null;
  let rs=s.slice(0,-1).toUpperCase(); const ss=s.slice(-1).toLowerCase();
  if(rs==='10') rs='T';
  const r=RANKS.indexOf(rs), su=SUITS.indexOf(ss);
  if(rs.length!==1||r<0||su<0) return undefined;
  return (r+2)*4+su;
}
function newDeck(){ const d=[]; for(let r=2;r<=14;r++) for(let s=0;s<4;s++) d.push(r*4+s); return d; }
function rnd(n){ const a=new Uint32Array(1); crypto.getRandomValues(a); return a[0]%n; }
function shuffle(d){ for(let i=d.length-1;i>0;i--){ const j=rnd(i+1); const t=d[i]; d[i]=d[j]; d[j]=t; } return d; }

/* ---------- evaluator ---------- */
const CNT=new Int8Array(15);
const B5=1048576;
function eval5(a,b,c,d,e){
  const s=a&3, flush=((b&3)===s)&&((c&3)===s)&&((d&3)===s)&&((e&3)===s);
  CNT.fill(0); CNT[a>>2]++; CNT[b>>2]++; CNT[c>>2]++; CNT[d>>2]++; CNT[e>>2]++;
  const g=[];
  for(let r=14;r>=2;r--) if(CNT[r]) g.push(CNT[r]*16+r);
  g.sort((x,y)=>y-x);
  let straight=0;
  if(g.length===5){
    const hi=g[0]&15, lo=g[4]&15;
    if(hi-lo===4) straight=hi; else if(hi===14 && (g[1]&15)===5) straight=5;
  }
  let cat;
  if(straight&&flush) cat=8;
  else if((g[0]>>4)===4) cat=7;
  else if((g[0]>>4)===3 && (g[1]>>4)===2) cat=6;
  else if(flush) cat=5;
  else if(straight) cat=4;
  else if((g[0]>>4)===3) cat=3;
  else if((g[0]>>4)===2 && (g[1]>>4)===2) cat=2;
  else if((g[0]>>4)===2) cat=1;
  else cat=0;
  let v=0, k=0;
  if(cat===8||cat===4){ v=straight; k=1; }
  else for(const x of g){ v=v*16+(x&15); k++; }
  for(;k<5;k++) v*=16;
  return cat*B5+v;
}
const COMB={};
function comb(n,k){
  const key=n+','+k; if(COMB[key]) return COMB[key];
  const res=[], cur=[];
  (function go(s){ if(cur.length===k){ res.push(cur.slice()); return; } for(let i=s;i<n;i++){ cur.push(i); go(i+1); cur.pop(); } })(0);
  return COMB[key]=res;
}
function bestHand(hole,board,omaha){
  let bs=-1, bc=null;
  if(omaha){
    if(board.length<3) return null;
    for(const p of comb(hole.length,2)){ const h0=hole[p[0]], h1=hole[p[1]];
      for(const t of comb(board.length,3)){ const x=board[t[0]], y=board[t[1]], z=board[t[2]]; const sc=eval5(h0,h1,x,y,z); if(sc>bs){ bs=sc; bc=[h0,h1,x,y,z]; } } }
  } else {
    const all=hole.concat(board); if(all.length<5) return null;
    for(const q of comb(all.length,5)){ const sc=eval5(all[q[0]],all[q[1]],all[q[2]],all[q[3]],all[q[4]]); if(sc>bs){ bs=sc; bc=q.map(i=>all[i]); } }
  }
  return {score:bs, cards:bc};
}

function handName(score){
  const cat=Math.floor(score/B5), g0=Math.floor(score/65536)%16, g1=Math.floor(score/4096)%16;
  const R=rankLabel;
  switch(cat){
    case 8: return g0===14?'Thùng phá sảnh hoàng gia':`Thùng phá sảnh đến ${R(g0)}`;
    case 7: return `Tứ quý ${R(g0)}`;
    case 6: return `Cù lũ ${R(g0)}-${R(g1)}`;
    case 5: return `Thùng, cao ${R(g0)}`;
    case 4: return `Sảnh đến ${R(g0)}`;
    case 3: return `Bộ ba ${R(g0)}`;
    case 2: return `Hai đôi ${R(g0)} và ${R(g1)}`;
    case 1: return `Đôi ${R(g0)}`;
    default: return `Mậu thầu ${R(g0)}`;
  }
}
/* ---------- sound ---------- */
const SND={ on:store.get('bsm-snd',true), ctx:null,
  init(){ if(this.ctx) return; try{ this.ctx=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} },
  play(type){
    if(!this.on||!this.ctx) return;
    const c=this.ctx, t=c.currentTime;
    try{
      if(type==='card'){
        const len=Math.floor(c.sampleRate*.05), b=c.createBuffer(1,len,c.sampleRate), d=b.getChannelData(0);
        for(let i=0;i<len;i++) d[i]=(Math.random()*2-1)*Math.pow(1-i/len,3);
        const s=c.createBufferSource(); s.buffer=b; const f=c.createBiquadFilter(); f.type='bandpass'; f.frequency.value=2400; f.Q.value=.8;
        const g=c.createGain(); g.gain.value=.32; s.connect(f).connect(g).connect(c.destination); s.start(t);
      } else if(type==='chip'){
        [[2600,0],[3500,.035],[3000,.07]].forEach(([fr,dl])=>{ const o=c.createOscillator(); o.type='triangle'; o.frequency.value=fr; const g=c.createGain();
          g.gain.setValueAtTime(.0001,t+dl); g.gain.exponentialRampToValueAtTime(.09,t+dl+.004); g.gain.exponentialRampToValueAtTime(.0001,t+dl+.08);
          o.connect(g).connect(c.destination); o.start(t+dl); o.stop(t+dl+.1); });
      } else if(type==='win'){
        [523,659,784,1047].forEach((fr,i)=>{ const o=c.createOscillator(); o.type='sine'; o.frequency.value=fr; const g=c.createGain(); const st=t+i*.09;
          g.gain.setValueAtTime(.0001,st); g.gain.exponentialRampToValueAtTime(.12,st+.01); g.gain.exponentialRampToValueAtTime(.0001,st+.35);
          o.connect(g).connect(c.destination); o.start(st); o.stop(st+.4); });
      } else if(type==='turn'){
        const o=c.createOscillator(); o.type='sine'; o.frequency.value=880; const g=c.createGain();
        g.gain.setValueAtTime(.0001,t); g.gain.exponentialRampToValueAtTime(.07,t+.01); g.gain.exponentialRampToValueAtTime(.0001,t+.25);
        o.connect(g).connect(c.destination); o.start(t); o.stop(t+.3);
      }
    }catch(e){}
  }
};

addEventListener('pointerdown',()=>SND.init(),{once:true});
addEventListener('keydown',()=>SND.init(),{once:true});
/* ---------- constants ---------- */
const VARIANTS=[{id:'NLHE',label:"Hold'em",n:2,omaha:false},{id:'PINE',label:'Pineapple',n:3,omaha:false,discard:'pre'},{id:'CPINE',label:'Crazy Pine',n:3,omaha:false,discard:'flop'}].concat([4,5,6,7,8,9,10].map(n=>({id:'PLO'+n,label:'PLO'+n,n,omaha:true})));
const variantOf=id=>VARIANTS.find(v=>v.id===id)||VARIANTS[0];
const maxSeats=(n,dbl)=>Math.min(10,Math.floor((52-(dbl?16:8))/n));
const AV_COLORS=['#3E5BA9','#8A3FA8','#B8573A','#2E8A7A','#A8862E','#5A6B8C','#B03A62','#3A8A45','#6A4FB8','#C0392B'];
const fmt=n=>Math.round(n||0).toLocaleString('en-US');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const esc=s=>String(s).replace(/[&<>"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
const cleanName=s=>String(s||'').replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/g,'').trim().slice(0,14);
const G={snap:null,rendered:null,mySeat:-1,seats:0,cfg:null,dom:[],win:null,bannerT:null};

/* ---------- token ---------- */
function myToken(){ let t=store.get('lc-token',null); if(!t){ t=crypto.getRandomValues(new Uint8Array(16)); t=btoa(String.fromCharCode(...t)).replace(/[^A-Za-z0-9]/g,'').slice(0,24); store.set('lc-token',t); } return t; }

/* ---------- card DOM (reused helpers from head) ---------- */
const FX=$('#fx'), deckEl=$('#deck'), potEl=$('#potWrap'), slots=[...document.querySelectorAll('#board .slot')], slots2=[...document.querySelectorAll('#board2 .slot')];
function center(el){ const r=el.getBoundingClientRect(); return {x:r.left+r.width/2, y:r.top+r.height/2}; }
function makeCard(c,size,up){
  const d=document.createElement('div'); d.className='card '+size+(up?' up':'');
  if(c!=null){ const r=cRank(c), s=cSuit(c); d.dataset.c=c;
    d.innerHTML=`<div class="inner"><div class="face front ${SUIT_NAME[s]}"><span class="r">${rankLabel(r)}</span><span class="s">${SUIT_CH[s]}</span><span class="pip">${SUIT_CH[s]}</span></div><div class="face back"></div></div>`;
    d.setAttribute('aria-label',cStr(c));
  } else d.innerHTML='<div class="inner"><div class="face back"></div></div>';
  return d;
}
function flyNode(node,from,to,o={}){
  node.style.position='fixed'; node.style.left='0'; node.style.top='0'; node.style.margin='0'; FX.appendChild(node);
  const w=node.offsetWidth,h=node.offsetHeight;
  return node.animate([{transform:`translate(${from.x-w/2}px,${from.y-h/2}px) rotate(${o.r0||0}deg) scale(${o.s0??1})`,opacity:o.o0??1},{transform:`translate(${to.x-w/2}px,${to.y-h/2}px) rotate(${o.r1||0}deg) scale(${o.s1??1})`,opacity:o.o1??1}],{duration:RM?1:(o.dur||420),delay:RM?0:(o.delay||0),easing:o.ease||'cubic-bezier(.2,.8,.2,1)',fill:'both'}).finished.catch(()=>{}).then(()=>node.remove());
}
function chipsFly(fromEl,toEl,n=2,gold=false){ if(!fromEl||!toEl) return; const a=center(fromEl),b=center(toEl); for(let i=0;i<n;i++){ const ch=document.createElement('span'); ch.className='chip'+(gold?' gold':''); flyNode(ch,{x:a.x+(Math.random()*8-4),y:a.y},{x:b.x+(Math.random()*8-4),y:b.y},{dur:400,delay:i*50}); } setTimeout(()=>SND.play('chip'),RM?0:200); }
function sortHandC(h,omaha){ return h.slice().sort((x,y)=> omaha ? (cSuit(x)-cSuit(y))||(cRank(y)-cRank(x)) : (cRank(y)-cRank(x))||(cSuit(x)-cSuit(y))); }
function handLabel(hole,board,omaha){ const b=bestHand(hole,board,omaha); if(b) return handName(b.score); if(!omaha&&hole.length===2&&cRank(hole[0])===cRank(hole[1])) return `Đôi ${rankLabel(cRank(hole[0]))}`; return ''; }

/* ---------- WS connection ---------- */
const WS={ws:null,code:null,token:null,owner:false,backoff:800,wantClose:false,
  open(code){
    this.wantClose=false; this.code=code; this.token=myToken();
    const proto=location.protocol==='https:'?'wss':'ws';
    try{ this.ws=new WebSocket(`${proto}://${location.host}/ws`); }catch(e){ this.retry(); return; }
    netLabel(false,'Đang kết nối');
    this.ws.onopen=()=>{ this.backoff=800; this.send({t:'join',code,token:this.token,name:store.get('lc-name','Bạn')}); clearInterval(this._hb); this._hb=setInterval(()=>this.send({t:'hb'}),30000); };
    this.ws.onmessage=e=>{ let m; try{ m=JSON.parse(e.data); }catch(_){ return; } this.handle(m); };
    this.ws.onclose=()=>{ if(this.wantClose) return; netLabel(false,'Mất kết nối, đang thử lại'); this.retry(); };
    this.ws.onerror=()=>{};
  },
  retry(){ if(this.wantClose) return; clearTimeout(this._t); this._t=setTimeout(()=>this.open(this.code),this.backoff); this.backoff=Math.min(this.backoff*1.6,8000); },
  send(m){ if(this.ws&&this.ws.readyState===1) this.ws.send(JSON.stringify(m)); },
  close(){ this.wantClose=true; clearTimeout(this._t); clearInterval(this._hb); if(this.ws){ try{ this.ws.close(); }catch(e){} this.ws=null; } },
  handle(m){
    if(m.t==='joined'){ this.token=m.token; this.owner=m.owner; store.set('lc-token',m.token); netLabel(true,'Đã kết nối'); return; }
    if(m.t==='nojoin'){ $('#tTitle').textContent='Không vào được bàn'; toast(m.msg||'Bàn không tồn tại.'); netLabel(false,'Không có bàn'); return; }
    if(m.t==='err'){ toast(m.msg); return; }
    if(m.t==='ledger'){ renderLedger(m.ledger); return; }
    if(m.t==='state'){ onState(m); return; }
  }
};
function netLabel(on,text){ const n=$('#tableNet'); n.classList.toggle('on',on); n.textContent=text; }
let toastT=null;
function toast(msg){ let t=$('#toastEl'); if(!t){ t=document.createElement('div'); t.id='toastEl'; t.className='toast glass'; document.body.appendChild(t); } t.textContent=msg; t.hidden=false; clearTimeout(toastT); toastT=setTimeout(()=>t.hidden=true,3200); }

/* ---------- views ---------- */
const views={lobby:$('#lobbyView'),create:$('#createView'),table:$('#tableView')};
function show(n){ Object.entries(views).forEach(([k,v])=>v.hidden=k!==n); window.scrollTo(0,0); }

/* lobby */
let lobbyTimer=null;
async function loadLobby(){
  try{ const r=await fetch('/api/rooms'); const {rooms}=await r.json(); renderRooms(rooms); }
  catch(e){ $('#liveList').innerHTML='<div class="empty"><p>Không tải được danh sách bàn.</p></div>'; }
}
function renderRooms(rooms){
  const box=$('#liveList');
  if(!rooms.length){ box.innerHTML='<div class="empty"><p>Chưa có bàn nào đang mở. Tạo bàn mới để bắt đầu.</p></div>'; return; }
  box.innerHTML='<div class="trow thead"><span>Bàn</span><span>Thể thức</span><span>Blinds</span><span>Ghế</span><span>Buy-in</span><span></span></div>'+rooms.map(t=>
    `<div class="trow"><div class="tname">${esc(t.name)}<small>mã ${esc(t.code)}, ${t.players} đang xem</small></div>
      <div class="c-game num">${esc(t.label)}</div><div class="c-blinds num">${fmt(t.sb)}/${fmt(t.bb)}</div><div class="c-seats num">${t.taken}/${t.seats}</div><div class="c-buy num">${fmt(t.min)}–${fmt(t.max)}</div>
      <div class="mob">${esc(t.label)}, ${fmt(t.sb)}/${fmt(t.bb)}, ${t.taken}/${t.seats}</div>
      <div class="tact"><a class="primary" href="#/t/${esc(t.code)}">Vào bàn</a></div></div>`).join('');
}
$('#joinBtn').onclick=()=>{ let v=$('#joinCode').value.trim(); const m=v.match(/#\/t\/([A-Za-z0-9_-]+)/)||v.match(/[?&]code=([A-Za-z0-9_-]+)/); if(m) v=m[1]; v=v.replace(/[^A-Za-z0-9_-]/g,''); if(v) location.hash='#/t/'+v; };
$('#joinCode').addEventListener('keydown',e=>{ if(e.key==='Enter') $('#joinBtn').click(); });

/* create */
let draft;
function resetDraft(){ const l=store.get('lc-draft-o',{}); draft={name:'',hero:store.get('lc-name',l.hero||'Bạn'),variant:l.variant||'PLO6',seats:l.seats||6,sb:l.sb||5,bb:l.bb||10,buyin:l.buyin||1000,min:l.min||400,max:l.max||2000,actTime:l.actTime||30,bank:l.bank??60,straddle:!!l.straddle,doubleBoard:l.doubleBoard||'off',bombAnte:l.bombAnte||2,bombEvery:l.bombEvery??0}; }
function syncForm(){ $('#cName').value=draft.name; $('#cHero').value=draft.hero; $('#cSB').value=draft.sb; $('#cBB').value=draft.bb; $('#cBuy').value=draft.buyin; $('#cMin').value=draft.min; $('#cMax').value=draft.max; $('#cAct').value=draft.actTime; $('#cBank').value=draft.bank; $('#cStraddle').checked=draft.straddle; $('#cDouble').value=draft.doubleBoard; $('#cBombAnte').value=draft.bombAnte; $('#cBombEvery').value=draft.bombEvery; renderCreate(); }
function renderCreate(){
  const box=$('#cVariants'); box.innerHTML='';
  VARIANTS.forEach(v=>{ const b=document.createElement('button'); b.type='button'; b.setAttribute('aria-pressed',String(v.id===draft.variant)); b.innerHTML=`${v.label}<small>tối đa ${maxSeats(v.n)} ghế</small>`; b.onclick=()=>{ draft.variant=v.id; renderCreate(); }; box.appendChild(b); });
  const dbl=draft.doubleBoard!=='off', v=variantOf(draft.variant), m=maxSeats(v.n,dbl), r=$('#cCount');
  r.max=m; draft.seats=Math.min(draft.seats,m); r.value=draft.seats; $('#cCountLbl').textContent=draft.seats;
  $('#cSeatHint').textContent=`Mỗi người ${v.n} lá${v.discard?(v.discard==='pre'?', bỏ 1 lá trước flop':', bỏ 1 lá sau vòng cược flop'):''}. ${m} ghế × ${v.n} + ${dbl?'10 lá 2 board + 6 burn':'5 board + 3 burn'} = ${m*v.n+(dbl?16:8)} lá, trong bộ 52 lá.`;
  $('#pvName').textContent=draft.name.trim()||'Bàn mới'; $('#pvMeta').textContent=`${v.label} ${v.omaha?'Pot Limit':'No Limit'}`;
  const pt=$('#pvTable'); pt.innerHTML=''; for(let i=0;i<draft.seats;i++){ const a=Math.PI/2+i*2*Math.PI/draft.seats, d=document.createElement('i'); d.className=i===0?'me':''; d.style.left=(50+46*Math.cos(a))+'%'; d.style.top=(50+42*Math.sin(a))+'%'; pt.appendChild(d); }
  $('#pvKv').innerHTML=`<dt>Blinds</dt><dd>${fmt(draft.sb)}/${fmt(draft.bb)}</dd><dt>Buy-in của bạn</dt><dd>${fmt(draft.buyin)}</dd><dt>Khoảng buy-in</dt><dd>${fmt(draft.min)}–${fmt(draft.max)}</dd><dt>Ghế</dt><dd>${draft.seats} người thật</dd><dt>Lượt / timebank</dt><dd>${draft.actTime}s / ${draft.bank}s</dd><dt>Straddle</dt><dd>${draft.straddle?'Có':'Không'}</dd><dt>Double board</dt><dd>${{off:'Tắt',bomb:'Chỉ bomb pot',always:'Mọi ván'}[draft.doubleBoard]}</dd><dt>Bomb pot</dt><dd>${draft.bombAnte} BB, ${draft.bombEvery?`mỗi ${draft.bombEvery} ván`:'khi chủ bàn bật'}</dd>`;
}
const numIn=(id,key)=>{ $(id).oninput=e=>{ draft[key]=Math.round(Number(e.target.value)); renderCreate(); }; };
$('#cName').oninput=e=>{ draft.name=e.target.value; renderCreate(); };
$('#cHero').oninput=e=>{ draft.hero=e.target.value; store.set('lc-name',cleanName(e.target.value)||'Bạn'); };
$('#cCount').oninput=e=>{ draft.seats=+e.target.value; renderCreate(); };
numIn('#cBombAnte','bombAnte'); numIn('#cBombEvery','bombEvery');
$('#cStraddle').onchange=e=>{ draft.straddle=e.target.checked; renderCreate(); };
$('#cDouble').onchange=e=>{ draft.doubleBoard=e.target.value; renderCreate(); };
numIn('#cSB','sb'); numIn('#cBB','bb'); numIn('#cBuy','buyin'); numIn('#cMin','min'); numIn('#cMax','max'); numIn('#cAct','actTime'); numIn('#cBank','bank');
function validate(d){
  if(!(d.sb>=1&&d.bb>=1)) return 'Blinds phải dương.'; if(d.sb>d.bb) return 'SB không được lớn hơn BB.';
  if(!(d.min>=d.bb)) return 'Buy-in tối thiểu ≥ 1 BB.'; if(!(d.max>=d.min)) return 'Buy-in tối đa ≥ tối thiểu.';
  if(d.buyin!=null&&!(d.buyin>=d.min&&d.buyin<=d.max)) return `Buy-in của bạn phải trong ${fmt(d.min)}–${fmt(d.max)}.`;
  if(!(d.actTime>=3&&d.actTime<=600)) return 'Lượt 3–600 giây.'; if(!(d.bank>=0&&d.bank<=3600)) return 'Timebank 0–3600 giây.';
  if(d.bombAnte!=null&&!(d.bombAnte>=1&&d.bombAnte<=100)) return 'Ante bomb pot 1–100 BB.'; if(d.bombEvery!=null&&!(d.bombEvery>=0&&d.bombEvery<=100)) return 'Bomb pot mỗi 0–100 ván.'; return '';
}
$('#cPlay').onclick=async()=>{
  const name=draft.name.trim(); if(!name){ $('#cErr').textContent='Đặt tên bàn.'; $('#cName').focus(); return; }
  const err=validate(draft); if(err){ $('#cErr').textContent=err; return; }
  $('#cErr').textContent=''; store.set('lc-name',cleanName(draft.hero)||'Bạn');
  const {name:_n,...rest}=draft; store.set('lc-draft-o',rest);
  try{
    const res=await fetch('/api/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...draft,name,ownerToken:myToken()})});
    const d=await res.json(); if(d.error){ $('#cErr').textContent=d.error; return; }
    store.set('lc-token',d.ownerToken); pendingBuyIn=draft.buyin; location.hash='#/t/'+d.code;
  }catch(e){ $('#cErr').textContent='Không tạo được bàn. Máy chủ chưa chạy?'; }
};

/* ---------- table build ---------- */
const portraitMQ=matchMedia('(max-width: 700px) and (orientation: portrait)');
function buildSeats(n,mySeat){
  const seatsEl=$('#seats'), betsEl=$('#bets'); seatsEl.innerHTML=''; betsEl.innerHTML=''; G.dom=[];
  $('#table').classList.toggle('crowded',n>6);
  const base=mySeat>=0?mySeat:(n>=2?Math.floor(n/2):0);
  for(let s=0;s<n;s++){
    const rel=(s-base+n)%n, a=Math.PI/2+rel*2*Math.PI/n;
    const seat=document.createElement('div'); seat.className='seat empty';
    seat.style.left=(50+47*Math.cos(a))+'%'; seat.style.top=(50+45*Math.sin(a))+'%';
    seat.innerHTML='<div class="hole"></div><div class="avatar"><span class="ini"></span><svg viewBox="0 0 68 68"><circle cx="34" cy="34" r="30"/></svg><span class="cd"></span></div><div class="plate"><span class="nm"></span><span class="st"></span><span class="cdm"></span><i class="tbar"></i></div><div class="bubble"></div><div class="handchip"></div><button class="sit" hidden>Ngồi</button>';
    seatsEl.appendChild(seat);
    const bet=document.createElement('div'); bet.className='bet'; bet.innerHTML='<span class="chip"></span><b></b>'; betsEl.appendChild(bet);
    const q=x=>seat.querySelector(x);
    G.dom[s]={seat,hole:q('.hole'),av:q('.avatar'),ini:q('.ini'),ring:q('circle'),cd:q('.cd'),cdm:q('.cdm'),nm:q('.nm'),st:q('.st'),tbar:q('.tbar'),bubble:q('.bubble'),hc:q('.handchip'),sit:q('.sit'),bet,betAmt:bet.querySelector('b'),angle:a,rel};
    G.dom[s].sit.onclick=()=>openSit(s);
    seat.querySelector('.avatar').addEventListener('dblclick',()=>{ if(WS.owner&&G.snap&&G.snap.seats[s]&&!G.snap.seats[s].you) hostKick(s); });
  }
  layoutBets(); deckEl.innerHTML=''; for(let i=0;i<3;i++) deckEl.appendChild(makeCard(null,'xs'));
}
function layoutBets(){ const portrait=portraitMQ.matches; G.dom.forEach(e=>{ if(!e) return; const c=Math.cos(e.angle),s=Math.sin(e.angle); if(e.rel===0){ e.bet.style.left='50%'; e.bet.style.top=(50+(portrait?22:19))+'%'; return; } e.bet.style.left=(50+(portrait?30:31)*c)+'%'; e.bet.style.top=(50+(portrait?(38-10*Math.abs(s)):27)*s)+'%'; }); }
portraitMQ.addEventListener('change',layoutBets);
function seatColor(i,me){ return `radial-gradient(circle at 35% 30%, rgba(255,255,255,.25), transparent 60%), ${me?'#C8353B':AV_COLORS[i%AV_COLORS.length]}`; }

/* ---------- snapshot renderer ---------- */
function setBanner(em,rest){ const b=$('#banner'); G.bannerT=[em||'',rest||'']; b.classList.remove('show'); void b.offsetWidth; $('#bnEm').textContent=em||''; $('#bnRest').textContent=rest||''; if(em||rest) b.classList.add('show'); }
let turnAnims=[],cdTimer=null,turnKey='';
function renderTurn(t){
  const key=t?`${t.seat}|${t.ph}|${Math.round(t.end/700)}`:'';
  if(key===turnKey) return; turnKey=key;
  turnAnims.forEach(a=>a.cancel()); turnAnims=[]; clearInterval(cdTimer);
  G.dom.forEach(e=>{ if(e){ e.seat.classList.remove('turn','bank'); e.cd.textContent=''; e.cdm.textContent=''; } });
  const pt=$('#pTimer'); pt.textContent=''; pt.classList.remove('bank');
  if(!t||!G.dom[t.seat]) return;
  const e=G.dom[t.seat], rem=Math.max(0,t.end-Date.now()), frac=t.tot?clamp(rem/t.tot,0,1):0;
  e.seat.classList.add('turn'); e.seat.classList.toggle('bank',t.ph==='bank');
  turnAnims.push(e.ring.animate([{strokeDashoffset:189*(1-frac)},{strokeDashoffset:189}],{duration:Math.max(1,rem),fill:'forwards'}));
  turnAnims.push(e.tbar.animate([{width:(frac*100)+'%'},{width:'0%'}],{duration:Math.max(1,rem),fill:'forwards'}));
  if(t.hu){ const isMe=t.seat===G.mySeat; const tick=()=>{ const r=Math.max(0,Math.ceil((t.end-Date.now())/1000)); if(isMe){ e.cdm.textContent=r+'s'; pt.textContent=(t.ph==='bank'?'Timebank ':'')+r+'s'; pt.classList.toggle('bank',t.ph==='bank'); } else e.cd.textContent=r; }; tick(); cdTimer=setInterval(tick,250); }
}
function onState(s){
  if(G.rendered&&s.rev<=G.rendered.rev&&s.handNo===G.rendered.handNo) { /* allow */ }
  const P=G.rendered; G.snap=s;
  const v=variantOf(s.cfg.variant||(s.cfg.omaha?('PLO'+s.cfg.n):'NLHE'));
  G.cfg={...s.cfg,label:v.label,omaha:v.omaha,n:v.n};
  const my=s.you.seat;
  if(!P||G.seats!==s.cfg.seats||G.mySeat!==my){ G.seats=s.cfg.seats; G.mySeat=my; buildSeats(s.cfg.seats,my); G.rebuilt=true; }
  const rebuilt=G.rebuilt; G.rebuilt=false;
  const PP=rebuilt?null:P;
  WS.owner=s.you.owner;
  $('#tStand').hidden=my<0; $('#tSitout').hidden=my<0; $('#tSettings').hidden=!s.you.owner;
  $('#codePill').textContent=WS.code||'';
  const active=s.phase!=='idle'&&s.phase!=='waiting';
  const newHand=!PP||PP.handNo!==s.handNo;
  $('#board2').hidden=!s.dbl&&!(s.board2&&s.board2.length); document.querySelector('.center').classList.toggle('dbl',!$('#board2').hidden);
  renderPills(s);
  $('#tStraddle').hidden=!(my>=0&&s.cfg.straddle); $('#tStraddle').classList.toggle('on',!!s.you.straddle); $('#tStraddle').textContent=s.you.straddle?'Straddle: bật':'Straddle';
  $('#tBomb').hidden=!s.you.owner; $('#tBomb').classList.toggle('on',!!s.nextBomb); $('#tBomb').textContent=s.nextBomb?'Bomb pot: ván tới':'Bomb pot';
  if(newHand){ slots2.forEach(x=>x.innerHTML=''); slots.forEach(x=>x.innerHTML=''); G.dom.forEach(e=>{ if(e){ e.hole.innerHTML=''; e.hole.dataset.key=''; e.hc.textContent=''; } }); setBanner('',''); }
  // seats
  s.seats.forEach((d,i)=>{ paintSeat(i,d,active); if(d&&PP&&PP.seats[i]&&!newHand){ const pd=PP.seats[i]; if(d.bet>pd.bet) chipsFly(seatChipFrom(i),G.dom[i].bet,2); if(pd.bet>0&&d.bet===0&&s.pot>PP.pot) chipsFly(G.dom[i].bet,potEl,2); if(d.win&&d.stack>pd.stack&&PP.handNo===s.handNo) chipsFly(potEl,seatChipFrom(i),4,true); } syncCards(i,d,s); });
  // board
  const shown=slots.filter(x=>x.querySelector('.card')).length, board=(s.board||[]).filter(Number.isInteger);
  if(board.length>shown){ animateBoard(slots,shown,board.slice(shown),board.length===5&&board.length-shown===1); }
  const board2=(s.board2||[]).filter(Number.isInteger), shown2=slots2.filter(x=>x.querySelector('.card')).length;
  if(board2.length>shown2){ setTimeout(()=>animateBoard(slots2,shown2,board2.slice(shown2),board2.length===5&&board2.length-shown2===1),160); }
  const bets=s.seats.reduce((a,d)=>a+(d?d.bet:0),0);
  $('#potAmt').textContent=fmt(s.pot); $('#potTotal').textContent=bets>0?`tổng ${fmt(s.pot+bets)}`:''; potEl.classList.toggle('show',s.pot+bets>0);
  moveButton(s.btn);
  // banner
  if(s.win){ if(!PP||JSON.stringify(PP.win)!==JSON.stringify(s.win)){ setBanner(s.win.name,' '+s.win.text); SND.play('win'); if(s.win.cards){ setTimeout(()=>highlight(s.win,s.dbl),700); } } }
  else if(PP&&PP.win) setBanner('','');
  renderTurn(s.turn?{seat:s.turn.seat,ph:s.turn.ph,end:Date.now()+(+s.turn.r||0),tot:+s.turn.tot||1,hu:!!s.turn.hu}:null);
  // my hand label + actions
  const meSeat=my>=0?s.seats[my]:null;
  if(meSeat&&Array.isArray(meSeat.cards)){
    let t=''; const three=!G.cfg.omaha&&meSeat.cards.length===3;
    if(!three){ t=handLabel(meSeat.cards,board,G.cfg.omaha); if(t&&board2.length>=3) t=`${t} / ${handLabel(meSeat.cards,board2,G.cfg.omaha)}`; }
    G.dom[my].hc.innerHTML=active&&!meSeat.folded&&t?`<b>${esc(t)}</b>`:''; }
  const picking=!!(s.discard&&s.discard.me&&my>=0);
  if(my>=0&&G.dom[my]) G.dom[my].seat.classList.toggle('picking',picking);
  if(picking){
    if(discardKey!==s.handNo+'|'+s.board.length){ discardKey=s.handNo+'|'+s.board.length; SND.play('turn'); }
    panelMode(true); UI.play.hidden=true; UI.status.textContent='Chọn 1 lá để bỏ (bấm vào lá trên tay)';
    const end=Date.now()+s.discard.r; clearInterval(discardTimer); const tick=()=>{ $('#pTimer').textContent=Math.max(0,Math.ceil((end-Date.now())/1000))+'s'; }; tick(); discardTimer=setInterval(tick,250);
    G.dom[my].hole.querySelectorAll('.card').forEach(el=>{ el.onclick=()=>{ G.dom[my].hole.querySelectorAll('.card').forEach(x=>x.classList.remove('chosen')); el.classList.add('chosen'); WS.send({t:'discard',card:+el.dataset.c}); }; });
  } else if(discardKey){ discardKey=''; clearInterval(discardTimer); $('#pTimer').textContent=''; if(!ctx) panelMode(false); }
  const myTurn=my>=0&&active&&s.turn&&s.turn.seat===my&&s.turn.hu;
  const key=myTurn?`${s.handNo}|${s.phase}|${s.cb}|${meSeat.bet}`:'';
  if(myTurn){ if(key!==actKey){ actKey=key; SND.play('turn'); showActions(ctxFrom(s),a=>WS.send({t:'act',handNo:s.handNo,type:a.type,to:a.to})); } }
  else { actKey=''; if(!picking){ if(my>=0) hideActions(); else panelMode(false); } }
  renderChat(s.chat);
  setInfo(s); G.rendered=s;
  // auto-open sit for newcomers once
  if(my<0&&pendingSit!=null&&s.seats[pendingSit]==null){ const ss=pendingSit; pendingSit=null; openSit(ss); }
}
function seatChipFrom(i){ return G.dom[i].seat.classList.contains('me')?G.dom[i].seat.querySelector('.plate'):G.dom[i].av; }
function paintSeat(i,d,active){
  const e=G.dom[i]; if(!e) return; const isMe=d&&d.you;
  e.seat.classList.toggle('empty',!d); e.seat.classList.toggle('me',!!isMe);
  if(!d){ e.nm.textContent=''; e.st.textContent=''; e.ini.textContent=''; e.av.style.background=''; e.seat.classList.remove('folded','allin','winner','waiting'); e.sit.hidden=!(G.mySeat<0); e.hc.textContent=''; return; }
  e.sit.hidden=true;
  e.nm.textContent=d.name+(d.owner?' ♦':''); e.ini.textContent=(d.name||'?').trim().charAt(0).toUpperCase(); e.av.style.background=seatColor(i,isMe);
  e.st.textContent=(d.allIn&&active)?'All-in':d.wait?'Chờ ván mới':(d.sittingOut&&!d.folded&&!active)?'Nghỉ':(d.disc?'Mất kết nối':fmt(d.stack));
  e.seat.classList.toggle('folded',!!d.folded&&active); e.seat.classList.toggle('allin',!!d.allIn&&active);
  e.seat.classList.toggle('winner',!!d.win); e.seat.classList.toggle('waiting',!!d.wait||((!!d.sittingOut||!!d.disc)&&!active));
  const b=e.bubble; if(d.bub){ if(b.textContent!==d.bub||!b.classList.contains('show')){ b.textContent=d.bub; let k=''; if(/Fold|bỏ/.test(d.bub))k='fold'; else if(/Raise|Bet|All-in/.test(d.bub))k='raise'; else if(/thùng|Đôi|Sảnh|Cù|Tứ|Hai|Bộ|Mậu/.test(d.bub))k='hand'; b.className='bubble show'+(k?' '+k:''); } } else b.className='bubble';
  e.bet.classList.toggle('show',d.bet>0); e.betAmt.textContent=fmt(d.bet);
}
function syncCards(i,d,s){
  const e=G.dom[i]; if(!e) return; const active=s.phase!=='idle'&&s.phase!=='waiting', N=G.cfg.n;
  let want='none', cards=null, cnt=0;
  if(d&&active&&!d.folded){ if(Array.isArray(d.cards)){ want='sh:'+d.cards.join(','); cards=d.cards; } else if(d.cards>0){ want='back:'+d.cards; cnt=d.cards; } }
  else if(d&&!active&&Array.isArray(d.cards)){ want='sh:'+d.cards.join(','); cards=d.cards; }
  else if(d&&!active&&!d.folded&&e.hole.dataset.key&&e.hole.dataset.key.startsWith('sh')) want=e.hole.dataset.key;
  if(want===(e.hole.dataset.key||'none')) return;
  const prevNone=(e.hole.dataset.key||'none')==='none';
  e.hole.dataset.key=want; e.hole.style.setProperty('--n',Math.max(2,d&&d.cards?(Array.isArray(d.cards)?d.cards.length:d.cards):N));
  if(want==='none'){ e.hole.innerHTML=''; return; }
  if(prevNone&&want.startsWith('back')){ e.hole.innerHTML=''; const from=center(deckEl),c=center(e.hole); for(let k=0;k<cnt;k++) flyNode(makeCard(null,'xs'),from,{x:c.x,y:c.y},{dur:360,delay:k*36+i*18,r0:-30}).then(()=>{ if(e.hole.dataset.key===want){ e.hole.appendChild(makeCard(null,'xs')); SND.play('card'); } }); return; }
  if(want.startsWith('back')){ e.hole.innerHTML=''; for(let k=0;k<cnt;k++) e.hole.appendChild(makeCard(null,'xs')); return; }
  const wasFaces=!prevNone&&!!e.hole.querySelector('.card.up');
  e.hole.innerHTML=''; const sorted=sortHandC(cards,G.cfg.omaha), els=sorted.map(c=>{ const x=makeCard(c,'xs',wasFaces); e.hole.appendChild(x); return x; });
  if(wasFaces) return;
  requestAnimationFrame(()=>els.forEach((x,k)=>setTimeout(()=>x.classList.add('up'),RM?0:k*45))); SND.play('card');
}
function animateBoard(row,start,cards,slow){
  const from=center(deckEl);
  Promise.all(cards.map((c,i)=>{ const slot=row[start+i]; return flyNode(makeCard(null,'md'),from,center(slot),{dur:440,delay:i*120,r0:-25,s0:.55}).then(()=>{ slot.innerHTML=''; const ce=makeCard(c,'md'); if(slow) ce.classList.add('slow'); slot.appendChild(ce); SND.play('card'); return ce; }); })).then(els=>{
    if(slow){ els.forEach(x=>x.classList.add('tease')); setTimeout(()=>els.forEach(x=>{ x.classList.add('up'); SND.play('card'); }),700); }
    else els.forEach((ce,k)=>setTimeout(()=>{ ce.classList.add('up'); SND.play('card'); },k*130));
  });
}
function moveButton(seat){ const e=G.dom[seat],d=$('#dealer'); if(!e||seat<0){ d.style.opacity='0'; return; } const a=e.angle+0.3; d.style.opacity='1'; d.style.left=(50+37*Math.cos(a))+'%'; d.style.top=(50+33*Math.sin(a))+'%'; }
function highlight(w,dbl){
  const mark=(row,cards)=>{ const set=new Set((cards||[]).map(String)); row.forEach(s=>{ const c=s.querySelector('.card'); if(c){ c.classList.toggle('win',set.has(c.dataset.c)); c.classList.toggle('dim',!set.has(c.dataset.c)); } }); return set; };
  const s1=mark(slots,w.cards), s2=dbl?mark(slots2,w.cards2):new Set();
  G.dom.forEach((e,i)=>{ if(!e) return; e.hole.querySelectorAll('.card').forEach(c=>{ const mine=(i===w.seat1&&s1.has(c.dataset.c))||(dbl&&i===w.seat2&&s2.has(c.dataset.c)); c.classList.toggle('win',mine); c.classList.toggle('dim',!mine); }); });
}
function renderPills(s){
  const p=$('#pills'), out=[];
  if(s.bomb) out.push('<span class="pill bomb">BOMB POT</span>');
  if(s.dbl) out.push('<span class="pill dbl">2 BOARD</span>');
  if(s.nextBomb&&!s.bomb) out.push('<span class="pill next">Ván tới: bomb pot</span>');
  const html=out.join(''); if(p.innerHTML!==html) p.innerHTML=html;
}
function setInfo(s){ $('#tTitle').textContent=s.cfg.name; const filled=s.seats.filter(Boolean).length; $('#info').innerHTML=`<b>${esc(s.cfg.label)}</b> ${s.cfg.omaha?'Pot Limit':'No Limit'}, blinds <b>${fmt(s.cfg.sb)}/${fmt(s.cfg.bb)}</b>, ${filled}/${s.cfg.seats} ghế, ${s.cfg.actTime}s + ${s.cfg.bank}s${s.handNo?`, ván #${s.handNo}`:''}`; }

/* ---------- action panel ---------- */
const UI={panel:$('#panel'),play:$('#play'),status:$('#pStatus'),bFold:$('#bFold'),bCall:$('#bCall'),bRaise:$('#bRaise'),raiseBox:$('#raiseBox'),slider:$('#rSlider'),input:$('#rInput'),hint:$('#rHint'),presets:$('#presets')};
let ctx=null,onAct=null,actKey='',discardKey='',discardTimer=null;
function panelMode(on){ UI.panel.hidden=!on; UI.play.hidden=!on; document.body.classList.toggle('acting',!!on); if(!on){ ctx=null; onAct=null; UI.raiseBox.hidden=true; } }
function ctxFrom(s){ const m=s.seats[s.you.seat], sumB=s.seats.reduce((a,d)=>a+(d?d.bet:0),0); const toCall=Math.max(0,s.cb-m.bet),allInTo=m.bet+m.stack,potNow=s.pot+sumB,potMax=s.cb+potNow+toCall; const max=G.cfg.omaha?Math.min(potMax,allInTo):allInTo,min=Math.min(s.cb+s.mr,max); const canRaise=m.stack>toCall&&s.seats.some((d,i)=>d&&i!==s.you.seat&&!d.folded&&!d.allIn&&(Array.isArray(d.cards)||d.cards>0)); return {toCall,min,max,canRaise,allInTo,potNow,cb:s.cb,stack:m.stack,omaha:G.cfg.omaha,bb:s.cfg.bb,label:Array.isArray(m.cards)?handLabel(m.cards,(s.board||[]).filter(Number.isInteger),G.cfg.omaha):''}; }
function showActions(c,cb){ ctx=c; onAct=cb; panelMode(true); UI.status.textContent=(c.toCall>0?`Cần ${fmt(Math.min(c.toCall,c.stack))} để call`:'Đến lượt bạn')+(c.label?`, đang có ${c.label}`:''); UI.bFold.hidden=c.toCall===0; UI.bCall.innerHTML=c.toCall===0?'Check':(c.toCall>=c.stack?`All-in<small>${fmt(c.stack)}</small>`:`Call<small>${fmt(c.toCall)}</small>`); if(c.canRaise&&c.max>c.toCall){ UI.bRaise.hidden=false; UI.slider.min=c.min; UI.slider.max=c.max; UI.slider.step=1; UI.presets.querySelectorAll('button[data-f]').forEach(b=>{ if(b.dataset.f==='all') b.textContent=c.omaha?'Pot':'All-in'; if(b.dataset.f==='1') b.hidden=c.omaha; }); setRaise(c.min); } else { UI.raiseBox.hidden=true; UI.bRaise.hidden=true; } UI.bCall.focus({preventScroll:true}); }
function hideActions(){ if(ctx) panelMode(false); }
function presetTo(f){ if(!ctx) return 0; if(f==='all') return ctx.max; return Math.round(ctx.cb+f*(ctx.potNow+ctx.toCall)); }
function setRaise(v){ if(!ctx) return; v=clamp(Math.round(Number(v)||ctx.min),ctx.min,ctx.max); UI.slider.value=v; UI.input.value=v; UI.slider.style.setProperty('--p',(ctx.max>ctx.min?(v-ctx.min)/(ctx.max-ctx.min)*100:100)+'%'); UI.hint.textContent=`${fmt(ctx.min)} – ${fmt(ctx.max)}`; UI.bRaise.innerHTML=(v>=ctx.allInTo?'All-in':(ctx.cb===0?'Bet':'Raise to'))+`<small>${fmt(v)}</small>`; UI.presets.querySelectorAll('button[data-f]').forEach(b=>b.setAttribute('aria-pressed',String(clamp(presetTo(b.dataset.f==='all'?'all':Number(b.dataset.f)),ctx.min,ctx.max)===v))); }
function act(type){ if(!ctx||!onAct) return; const c=ctx,cb=onAct; panelMode(false); if(type==='call') cb({type:c.toCall===0?'check':'call'}); else if(type==='raise') cb({type:'raise',to:Number(UI.input.value)}); else cb({type:'fold'}); }
const trayOpen=()=>!UI.raiseBox.hidden;
function raisePress(){ if(!ctx) return; if(!trayOpen()){ UI.raiseBox.hidden=false; UI.input.focus({preventScroll:true}); UI.input.select(); return; } act('raise'); }
UI.bFold.onclick=()=>act('fold'); UI.bCall.onclick=()=>act('call'); UI.bRaise.onclick=raisePress;
UI.slider.oninput=()=>setRaise(UI.slider.value); UI.input.onchange=()=>setRaise(UI.input.value);
$('#rMinus').onclick=()=>ctx&&setRaise(Number(UI.input.value)-ctx.bb); $('#rPlus').onclick=()=>ctx&&setRaise(Number(UI.input.value)+ctx.bb);
UI.presets.onclick=e=>{ const b=e.target.closest('button'); if(!b||!ctx) return; if(b.dataset.x){ UI.raiseBox.hidden=true; return; } setRaise(presetTo(b.dataset.f==='all'?'all':Number(b.dataset.f))); };
addEventListener('keydown',e=>{ if(!ctx||e.metaKey||e.ctrlKey||e.altKey) return; const t=document.activeElement,typing=t&&t.tagName==='INPUT'&&t.type!=='range'; if(e.key==='Enter'&&!UI.bRaise.hidden){ e.preventDefault(); raisePress(); return; } if(e.key==='Escape'&&trayOpen()){ UI.raiseBox.hidden=true; return; } if(typing) return; const k=e.key.toLowerCase(); if(k==='f'&&!UI.bFold.hidden) act('fold'); else if(k==='c') act('call'); else if(k==='r'&&!UI.bRaise.hidden) raisePress(); });

/* ---------- sit / stand / addon / rebuy ---------- */
let sitSeat=-1, pendingSit=null, pendingBuyIn=null;
function openSit(s){ if(G.mySeat>=0||!G.snap) return; sitSeat=s; const c=G.snap.cfg; $('#sitText').textContent=`Ghế ${s+1}, ${c.label}, blinds ${fmt(c.sb)}/${fmt(c.bb)}. Buy-in ${fmt(c.min)}–${fmt(c.max)}.`; $('#sitName').value=store.get('lc-name',''); const b=$('#sitBuy'); b.min=c.min; b.max=c.max; b.value=pendingBuyIn!=null?clamp(pendingBuyIn,c.min,c.max):clamp(Math.round((c.min+c.max)/2),c.min,c.max); pendingBuyIn=null; $('#sitErr').textContent=''; $('#sitDlg').showModal(); }
$('#sitCancel').onclick=()=>$('#sitDlg').close();
$('#sitOk').onclick=()=>{ const c=G.snap.cfg, name=cleanName($('#sitName').value), buy=Math.round(Number($('#sitBuy').value)); if(!name){ $('#sitErr').textContent='Nhập tên.'; return; } if(!(buy>=c.min&&buy<=c.max)){ $('#sitErr').textContent=`Buy-in ${fmt(c.min)}–${fmt(c.max)}.`; return; } store.set('lc-name',name); WS.send({t:'sit',seat:sitSeat,name,buyin:buy}); $('#sitDlg').close(); };
$('#tStand').onclick=()=>{ WS.send({t:'stand'}); toast('Bạn sẽ rời ghế sau ván này.'); };
let sittingOut=false;
$('#tSitout').onclick=()=>{ sittingOut=!sittingOut; WS.send({t:'sitout',out:sittingOut}); $('#tSitout').textContent=sittingOut?'Vào lại':'Nghỉ ván'; };
function hostKick(seat){ if(confirm('Mời người này rời bàn?')) WS.send({t:'kick',seat}); }

$('#tStraddle').onclick=()=>WS.send({t:'straddle',on:!(G.snap&&G.snap.you.straddle)});
$('#tBomb').onclick=()=>WS.send({t:'bomb'});
function colorsLabel(){ const two=document.body.classList.contains('c2'); document.querySelectorAll('[data-colors]').forEach(b=>b.textContent=two?'Bài 2 màu':'Bài 4 màu'); }
document.body.classList.toggle('c2',store.get('lc-c2',false)); colorsLabel();
document.querySelectorAll('[data-colors]').forEach(b=>b.onclick=()=>{ document.body.classList.toggle('c2'); store.set('lc-c2',document.body.classList.contains('c2')); colorsLabel(); });
/* invite */
$('#tInvite').onclick=()=>{ const link=location.origin+location.pathname+'#/t/'+WS.code; $('#inviteLink').value=link; $('#inviteCode').value=WS.code; $('#inviteDlg').showModal(); };
$('#inviteClose').onclick=()=>$('#inviteDlg').close();
$('#inviteCopy').onclick=async()=>{ try{ await navigator.clipboard.writeText($('#inviteLink').value); toast('Đã sao chép link.'); }catch(e){ $('#inviteLink').select(); document.execCommand&&document.execCommand('copy'); toast('Đã sao chép link.'); } };

/* settings */
$('#tSettings').onclick=()=>{ const c=G.snap.cfg; $('#sDouble').value=c.doubleBoard||'off'; $('#sBombAnte').value=c.bombAnte||2; $('#sBombEvery').value=c.bombEvery||0; $('#sStraddle').checked=!!c.straddle; $('#sSB').value=c.sb; $('#sBB').value=c.bb; $('#sAct').value=c.actTime; $('#sBank').value=c.bank; $('#sMin').value=c.min; $('#sMax').value=c.max; $('#sRefill').checked=false; $('#sErr').textContent=''; $('#setDlg').showModal(); };
$('#sCancel').onclick=()=>$('#setDlg').close();
$('#sOk').onclick=()=>{ const d={sb:+$('#sSB').value,bb:+$('#sBB').value,actTime:+$('#sAct').value,bank:+$('#sBank').value,min:+$('#sMin').value,max:+$('#sMax').value,bombAnte:+$('#sBombAnte').value,bombEvery:+$('#sBombEvery').value}; const err=validate(d); if(err){ $('#sErr').textContent=err; return; } WS.send({t:'cfg',...d,doubleBoard:$('#sDouble').value,straddle:$('#sStraddle').checked,refill:$('#sRefill').checked}); $('#setDlg').close(); };

/* chat */
$('#tChat').onclick=()=>{ $('#chatbox').classList.toggle('open'); $('#chatInput').focus(); };
$('#chatClose').onclick=()=>$('#chatbox').classList.remove('open');
function sendChat(){ const v=$('#chatInput').value.trim(); if(!v) return; WS.send({t:'say',text:v}); $('#chatInput').value=''; }
$('#chatSend').onclick=sendChat; $('#chatInput').addEventListener('keydown',e=>{ if(e.key==='Enter') sendChat(); });
let chatLen=0;
function renderChat(chat){ if(!chat) return; const box=$('#chatlist'); if(chat.length===chatLen) return; const near=box.scrollTop+box.clientHeight>box.scrollHeight-40; box.innerHTML=chat.map(m=>m.sys?`<p class="sys">${esc(m.text)}</p>`:`<p class="msg"><b>${esc(m.name)}:</b> ${esc(m.text)}</p>`).join(''); chatLen=chat.length; if(near) box.scrollTop=box.scrollHeight; }

/* ledger */
$('#tLedger').onclick=()=>{ WS.send({t:'ledger'}); $('#ledgerDlg').showModal(); };
$('#ledgerClose').onclick=()=>$('#ledgerDlg').close();
function renderLedger(rows){ const t=$('#ledgerT'); t.innerHTML='<tr><th>Người</th><th>Mua vào</th><th>Trên bàn</th><th>Đã rời với</th><th>Lời/lỗ</th></tr>'+rows.map(r=>`<tr><td>${esc(r.name)}</td><td>${fmt(r.buyin)}</td><td>${fmt(r.onTable)}</td><td>${fmt(r.cashout)}</td><td class="${r.net>0?'pos':r.net<0?'neg':''}">${r.net>0?'+':''}${fmt(r.net)}</td></tr>`).join(''); }

/* sound + snd button */
function sndLabel(){ document.querySelectorAll('[data-snd]').forEach(b=>b.textContent='Âm thanh: '+(SND.on?'bật':'tắt')); }
document.querySelectorAll('[data-snd]').forEach(b=>b.onclick=()=>{ SND.on=!SND.on; store.set('bsm-snd',SND.on); sndLabel(); }); sndLabel();

/* rebuy when busted (owner or player with 0 chips and seated) */
let rebuyShown=false;
function checkRebuy(){ if(!G.snap||G.mySeat<0) return; const me=G.snap.seats[G.mySeat]; if(me&&me.stack===0&&!me.folded&&G.snap.phase!=='hand'&&!rebuyShown){ rebuyShown=true; const c=G.snap.cfg; $('#rebuyText').textContent=`Bạn hết chip. Mua lại ${fmt(c.min)}–${fmt(c.max)}.`; $('#rebuyAmt').value=c.min; $('#rebuyErr').textContent=''; $('#rebuyDlg').showModal(); } if(me&&me.stack>0) rebuyShown=false; }
$('#rebuyCancel').onclick=()=>$('#rebuyDlg').close();
$('#rebuyOk').onclick=()=>{ const c=G.snap.cfg, v=Math.round(Number($('#rebuyAmt').value)); if(!(v>=c.min&&v<=c.max)){ $('#rebuyErr').textContent=`Buy-in ${fmt(c.min)}–${fmt(c.max)}.`; return; } WS.send({t:'addon',amt:v}); $('#rebuyDlg').close(); };
const _os=onState; onState=s=>{ _os(s); checkRebuy(); };

/* ---------- router ---------- */
function route(){
  const h=location.hash||'#/lobby';
  if(h.startsWith('#/create')){ WS.close(); show('create'); resetDraft(); syncForm(); }
  else if(h.startsWith('#/t/')){ const code=h.slice(4).replace(/[^A-Za-z0-9_-]/g,''); show('table'); $('#tTitle').textContent='Đang kết nối…'; $('#info').textContent=''; G.rendered=null; G.snap=null; G.mySeat=-1; G.seats=0; $('#seats').innerHTML=''; $('#bets').innerHTML=''; slots.forEach(x=>x.innerHTML=''); slots2.forEach(x=>x.innerHTML=''); $('#pills').innerHTML=''; panelMode(false); chatLen=0; $('#chatlist').innerHTML=''; WS.close(); WS.open(code); }
  else { WS.close(); show('lobby'); loadLobby(); clearInterval(lobbyTimer); lobbyTimer=setInterval(()=>{ if(!views.lobby.hidden) loadLobby(); },5000); }
}
addEventListener('hashchange',route);
route();
