# Lotus Club Poker — bản online

Poker nhiều người chơi thời gian thực. Hold'em, Pineapple, Crazy Pineapple, PLO4–PLO10,
straddle, bomb pot, double board, bài 2/4 màu, sổ buy-in, chat.

> Đây là **máy chủ Node.js + WebSocket**. Không chạy được trên GitHub Pages, Netlify,
> Vercel hay bất kỳ host "chỉ upload file HTML" nào. Cần một host chạy Node.

---

## Cách 1 — Render (miễn phí, không cần cài gì trên máy)

### Bước 1. Đưa code lên GitHub
1. Vào https://github.com/new → đặt tên repo (ví dụ `lotus-club`) → **Create repository**.
2. Trên trang repo mới, bấm **uploading an existing file**.
3. Giải nén file zip trên máy. Mở thư mục vừa giải nén, **chọn tất cả file và thư mục bên trong**
   (`package.json`, `render.yaml`, `src`, `public`, …) rồi kéo vào trang GitHub.
   ⚠️ Không kéo cả file `.zip`, và không kéo thư mục cha — `package.json` phải nằm ngay ở gốc repo.
4. Bấm **Commit changes**.

### Bước 2. Deploy trên Render
1. Vào https://dashboard.render.com → đăng nhập bằng GitHub.
2. **New +** → **Blueprint** → chọn repo `lotus-club` → **Apply**.
   (Render tự đọc `render.yaml`.)
   - Nếu không thấy Blueprint: **New +** → **Web Service** → chọn repo, rồi điền
     Runtime `Node`, Build `npm install`, Start `npm start`, Instance `Free`.
3. Chờ 1–3 phút đến khi trạng thái là **Live**. Bạn có link dạng
   `https://lotus-club-poker.onrender.com`.
4. Mở link → **Tạo bàn mới** → vào bàn → bấm **Mời** để lấy link gửi bạn bè.

**Lưu ý gói Free:** sau ~15 phút không ai vào, máy chủ ngủ; người đầu tiên vào lại sẽ chờ
khoảng 30–60 giây. Đang chơi thì không bị ngủ. Khởi động lại là mất các bàn đang mở
(dữ liệu chỉ nằm trong RAM). Muốn luôn bật thì nâng service đó lên gói trả phí.

---

## Cách 2 — Railway

1. https://railway.com → **New Project** → **Deploy from GitHub repo** → chọn repo.
2. Railway tự nhận Node, tự đặt `PORT`. Vào **Settings → Networking → Generate Domain** để có link.

## Cách 3 — Fly.io / VPS (dùng Dockerfile có sẵn)

```bash
fly launch        # chọn "Yes" khi hỏi dùng Dockerfile, internal port 8080
fly deploy
```
Trên VPS: `docker build -t lotus . && docker run -d -p 80:8080 lotus`

---

## Chạy thử trên máy

```bash
npm install
npm start            # http://localhost:8080
```
Cho người ngoài vào nhanh không cần deploy: mở terminal thứ 2 và chạy
`npx localtunnel --port 8080` (hoặc `cloudflared tunnel --url http://localhost:8080`).

---

## Gỡ lỗi deploy thường gặp

| Hiện tượng | Nguyên nhân | Cách sửa |
|---|---|---|
| `Could not read package.json` / `ENOENT package.json` | Code nằm trong thư mục con | Upload lại để `package.json` ở gốc repo, hoặc đặt **Root Directory** đúng thư mục |
| Trang mở được nhưng báo "Mất kết nối" | Đang dùng host tĩnh (Netlify, Vercel, Pages) | Deploy lên Render/Railway/Fly |
| Render báo "No open ports detected" | Start command sai | Start command phải là `npm start` |
| Lâu mới vào được lần đầu | Gói Free đang ngủ | Chờ 30–60 giây, hoặc nâng gói |
| Vào được nhưng bàn biến mất | Server vừa khởi động lại/deploy lại | Tạo bàn mới |

## Cấu trúc

- `src/engine.js` — đánh giá bài, thể thức, giới hạn ghế theo bộ 52 lá
- `src/room.js` — logic bàn: ghế, cược, đồng hồ, timebank, side pot, bomb pot, 2 board, Pineapple, sổ, chat
- `src/server.js` — HTTP + WebSocket, `/health` cho health check
- `public/` — giao diện
- `render.yaml`, `Dockerfile`, `Procfile` — cấu hình deploy
